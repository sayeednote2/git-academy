export type CourseLevel = "Beginner" | "Intermediate" | "Advanced" | "Expert";
export type DeliveryMode = "Live Online" | "Classroom" | "Hybrid" | "Self-Paced";

export interface Course {
  id: string;
  title: string;
  slug: string;
  vendor: string;
  vendorSlug: string;
  category: string;
  level: CourseLevel;
  duration: string;
  description: string;
  highlights: string[];
  certCode?: string;
  mode: DeliveryMode[];
  featured?: boolean;
}

export interface Vendor {
  name: string;
  slug: string;
  color: string;
  courses: Course[];
}

export interface Testimonial {
  name: string;
  role: string;
  company: string;
  quote: string;
  rating: number;
  course: string;
}

export interface BlogPost {
  id: string;
  title: string;
  slug: string;
  excerpt: string;
  category: string;
  author: string;
  date: string;
  readTime: string;
}

export const vendors: Vendor[] = [
  {
    name: "Cisco",
    slug: "cisco",
    color: "#049FD9",
    courses: [
      {
        id: "cisco-ccna",
        title: "CCNA — Cisco Certified Network Associate",
        slug: "ccna",
        vendor: "Cisco",
        vendorSlug: "cisco",
        category: "Networking",
        level: "Beginner",
        duration: "40 Hours",
        description: "Build a strong foundation in networking with CCNA. Cover network fundamentals, IP connectivity, security fundamentals, automation, and programmability.",
        highlights: ["Network Fundamentals", "IP Connectivity & Services", "Security Fundamentals", "Automation & Programmability"],
        certCode: "200-301",
        mode: ["Live Online", "Classroom"],
        featured: true,
      },
      {
        id: "cisco-encor",
        title: "ENCOR — Enterprise Network Core Technologies",
        slug: "encor",
        vendor: "Cisco",
        vendorSlug: "cisco",
        category: "Networking",
        level: "Advanced",
        duration: "40 Hours",
        description: "Master dual-stack architecture, virtualization, infrastructure, network assurance, security, and automation for enterprise networks.",
        highlights: ["Dual-Stack Architecture", "Virtualization", "Network Assurance", "Enterprise Security"],
        certCode: "350-401",
        mode: ["Live Online", "Classroom"],
        featured: true,
      },
      {
        id: "cisco-scor",
        title: "SCOR — Security Core Technologies",
        slug: "scor",
        vendor: "Cisco",
        vendorSlug: "cisco",
        category: "Security",
        level: "Advanced",
        duration: "40 Hours",
        description: "Implement and operate core security technologies including network security, cloud security, content security, and endpoint protection.",
        highlights: ["Network Security", "Cloud Security", "Content Security", "Endpoint Protection"],
        certCode: "350-701",
        mode: ["Live Online", "Classroom"],
      },
      {
        id: "cisco-dccor",
        title: "DCCOR — Data Center Core Technologies",
        slug: "dccor",
        vendor: "Cisco",
        vendorSlug: "cisco",
        category: "Data Center",
        level: "Advanced",
        duration: "40 Hours",
        description: "Implement data center infrastructure including networking, compute, storage networking, automation, and security.",
        highlights: ["Data Center Networking", "Compute Resources", "Storage Networking", "DC Automation"],
        certCode: "350-601",
        mode: ["Live Online", "Classroom"],
      },
      {
        id: "cisco-sdwan",
        title: "Cisco SD-WAN Solutions",
        slug: "sd-wan",
        vendor: "Cisco",
        vendorSlug: "cisco",
        category: "Networking",
        level: "Advanced",
        duration: "32 Hours",
        description: "Design, deploy, configure and manage Cisco SD-WAN solution in a large-scale live network.",
        highlights: ["SD-WAN Architecture", "Controller Deployment", "Policies & QoS", "Direct Internet Access"],
        certCode: "300-415",
        mode: ["Live Online", "Classroom"],
      },
      {
        id: "cisco-meraki",
        title: "Cisco Meraki Solutions",
        slug: "meraki",
        vendor: "Cisco",
        vendorSlug: "cisco",
        category: "Networking",
        level: "Intermediate",
        duration: "24 Hours",
        description: "Master cloud-managed networking with Cisco Meraki. Deploy and manage wireless, switching, security, and SD-WAN solutions.",
        highlights: ["Cloud-Managed Networking", "Meraki Dashboard", "Wireless Deployment", "SD-WAN Integration"],
        mode: ["Live Online", "Classroom"],
      },
      {
        id: "cisco-cyberops",
        title: "CyberOps Associate",
        slug: "cyberops",
        vendor: "Cisco",
        vendorSlug: "cisco",
        category: "Security",
        level: "Intermediate",
        duration: "30 Hours",
        description: "Prepare for the role of associate-level cybersecurity analyst within SOC environments.",
        highlights: ["SOC Operations", "Security Monitoring", "Host-Based Analysis", "Network Intrusion Analysis"],
        certCode: "200-201",
        mode: ["Live Online", "Classroom"],
      },
      {
        id: "cisco-devnet",
        title: "Cisco DevNet Associate",
        slug: "devnet",
        vendor: "Cisco",
        vendorSlug: "cisco",
        category: "Automation",
        level: "Intermediate",
        duration: "30 Hours",
        description: "Learn software development and design for Cisco platforms. APIs, Python, automation scripts, and network programmability.",
        highlights: ["Python for Networking", "REST APIs", "Cisco DNA Center", "Network Automation"],
        certCode: "200-901",
        mode: ["Live Online"],
      },
    ],
  },
  {
    name: "EC-Council",
    slug: "ec-council",
    color: "#D42027",
    courses: [
      {
        id: "ec-ceh",
        title: "CEH v12 — Certified Ethical Hacker",
        slug: "ceh-v12",
        vendor: "EC-Council",
        vendorSlug: "ec-council",
        category: "Ethical Hacking",
        level: "Intermediate",
        duration: "40 Hours",
        description: "Master 340+ attack technologies in a hands-on environment. The world's most advanced ethical hacking course with AI-driven tools.",
        highlights: ["340+ Attack Technologies", "AI-Driven Hacking Tools", "Real-World Lab Scenarios", "Over 220 Labs"],
        certCode: "312-50",
        mode: ["Live Online", "Classroom"],
        featured: true,
      },
      {
        id: "ec-chfi",
        title: "CHFI — Computer Hacking Forensic Investigator",
        slug: "chfi",
        vendor: "EC-Council",
        vendorSlug: "ec-council",
        category: "Forensics",
        level: "Advanced",
        duration: "40 Hours",
        description: "Master digital forensics to detect hacking attacks, extract evidence, and report cybercrime for prosecution.",
        highlights: ["Digital Forensics", "Evidence Collection", "Malware Forensics", "Cloud Forensics"],
        certCode: "312-49",
        mode: ["Live Online", "Classroom"],
      },
      {
        id: "ec-cpent",
        title: "CPENT — Certified Penetration Testing Professional",
        slug: "cpent",
        vendor: "EC-Council",
        vendorSlug: "ec-council",
        category: "Penetration Testing",
        level: "Expert",
        duration: "40 Hours",
        description: "Learn to pen test enterprise network environments that must be attacked, exploited, evaded, and defended.",
        highlights: ["Advanced Pen Testing", "IoT Pen Testing", "OT/SCADA Pen Testing", "Binary Analysis"],
        mode: ["Live Online"],
      },
      {
        id: "ec-csa",
        title: "CSA — Certified SOC Analyst",
        slug: "csa",
        vendor: "EC-Council",
        vendorSlug: "ec-council",
        category: "SOC Operations",
        level: "Intermediate",
        duration: "24 Hours",
        description: "Become proficient in SOC operations through training on SIEM deployment, advanced incident detection, and threat intelligence.",
        highlights: ["SOC Operations", "SIEM Deployment", "Incident Detection", "Threat Response"],
        mode: ["Live Online", "Classroom"],
      },
    ],
  },
  {
    name: "CompTIA",
    slug: "comptia",
    color: "#C8202F",
    courses: [
      {
        id: "comptia-secplus",
        title: "CompTIA Security+",
        slug: "security-plus",
        vendor: "CompTIA",
        vendorSlug: "comptia",
        category: "Security",
        level: "Beginner",
        duration: "40 Hours",
        description: "Validate baseline security skills. The globally recognized certification for foundational cybersecurity knowledge.",
        highlights: ["Threats & Vulnerabilities", "Architecture & Design", "Implementation", "Operations & Incident Response"],
        certCode: "SY0-701",
        mode: ["Live Online", "Classroom"],
        featured: true,
      },
      {
        id: "comptia-netplus",
        title: "CompTIA Network+",
        slug: "network-plus",
        vendor: "CompTIA",
        vendorSlug: "comptia",
        category: "Networking",
        level: "Beginner",
        duration: "40 Hours",
        description: "Validate your ability to design, configure, manage, and troubleshoot wired and wireless networks.",
        highlights: ["Network Architecture", "Network Operations", "Network Security", "Troubleshooting"],
        certCode: "N10-009",
        mode: ["Live Online", "Classroom"],
      },
      {
        id: "comptia-cysa",
        title: "CompTIA CySA+",
        slug: "cysa-plus",
        vendor: "CompTIA",
        vendorSlug: "comptia",
        category: "Security Analytics",
        level: "Intermediate",
        duration: "40 Hours",
        description: "Apply behavioral analytics to networks and devices to prevent, detect and combat cybersecurity threats.",
        highlights: ["Threat Detection", "Security Analytics", "Vulnerability Management", "Incident Response"],
        certCode: "CS0-003",
        mode: ["Live Online", "Classroom"],
      },
      {
        id: "comptia-aplus",
        title: "CompTIA A+",
        slug: "a-plus",
        vendor: "CompTIA",
        vendorSlug: "comptia",
        category: "IT Fundamentals",
        level: "Beginner",
        duration: "40 Hours",
        description: "The industry standard for establishing a career in IT. Covers hardware, software, troubleshooting, and operational procedures.",
        highlights: ["Hardware & Software", "Networking Concepts", "Mobile Devices", "OS Troubleshooting"],
        certCode: "220-1101/1102",
        mode: ["Live Online", "Classroom"],
      },
      {
        id: "comptia-cloudplus",
        title: "CompTIA Cloud+",
        slug: "cloud-plus",
        vendor: "CompTIA",
        vendorSlug: "comptia",
        category: "Cloud",
        level: "Intermediate",
        duration: "32 Hours",
        description: "Validate the skills needed to maintain and optimize cloud infrastructure services.",
        highlights: ["Cloud Architecture", "Security & Compliance", "Deployment", "Operations & Support"],
        certCode: "CV0-004",
        mode: ["Live Online"],
      },
    ],
  },
  {
    name: "Microsoft",
    slug: "microsoft",
    color: "#00A4EF",
    courses: [
      {
        id: "ms-az900",
        title: "AZ-900 — Azure Fundamentals",
        slug: "az-900",
        vendor: "Microsoft",
        vendorSlug: "microsoft",
        category: "Cloud",
        level: "Beginner",
        duration: "16 Hours",
        description: "Understand cloud concepts, Azure services, security, privacy, compliance, and Azure pricing and support.",
        highlights: ["Cloud Concepts", "Azure Services", "Security & Compliance", "Azure Pricing"],
        certCode: "AZ-900",
        mode: ["Live Online", "Classroom"],
      },
      {
        id: "ms-az104",
        title: "AZ-104 — Azure Administrator",
        slug: "az-104",
        vendor: "Microsoft",
        vendorSlug: "microsoft",
        category: "Cloud",
        level: "Intermediate",
        duration: "32 Hours",
        description: "Implement, manage, and monitor an organization's Azure environment including virtual networks, storage, and compute.",
        highlights: ["Azure Identity", "Virtual Networking", "Storage Management", "Compute Resources"],
        certCode: "AZ-104",
        mode: ["Live Online", "Classroom"],
      },
      {
        id: "ms-az500",
        title: "AZ-500 — Azure Security Engineer",
        slug: "az-500",
        vendor: "Microsoft",
        vendorSlug: "microsoft",
        category: "Cloud Security",
        level: "Advanced",
        duration: "32 Hours",
        description: "Implement security controls, maintain security posture, manage identity and access in Azure.",
        highlights: ["Identity & Access", "Platform Protection", "Security Operations", "Data & Application Security"],
        certCode: "AZ-500",
        mode: ["Live Online"],
        featured: true,
      },
    ],
  },
  {
    name: "AWS",
    slug: "aws",
    color: "#FF9900",
    courses: [
      {
        id: "aws-saa",
        title: "AWS Solutions Architect Associate",
        slug: "aws-solutions-architect",
        vendor: "AWS",
        vendorSlug: "aws",
        category: "Cloud",
        level: "Intermediate",
        duration: "40 Hours",
        description: "Design distributed systems and architectures on AWS. Cover compute, networking, storage, and database services.",
        highlights: ["Cloud Architecture", "High Availability", "Cost Optimization", "Security Best Practices"],
        certCode: "SAA-C03",
        mode: ["Live Online"],
      },
      {
        id: "aws-security",
        title: "AWS Security Specialty",
        slug: "aws-security-specialty",
        vendor: "AWS",
        vendorSlug: "aws",
        category: "Cloud Security",
        level: "Expert",
        duration: "32 Hours",
        description: "Demonstrate proficiency in securing AWS workloads. Data protection, incident response, and logging monitoring.",
        highlights: ["Incident Response", "Logging & Monitoring", "Infrastructure Security", "Data Protection"],
        certCode: "SCS-C02",
        mode: ["Live Online"],
      },
    ],
  },
  {
    name: "Fortinet",
    slug: "fortinet",
    color: "#EE3124",
    courses: [
      {
        id: "forti-nse4",
        title: "Fortinet NSE 4 — FortiGate Security",
        slug: "fortigate-security",
        vendor: "Fortinet",
        vendorSlug: "fortinet",
        category: "Network Security",
        level: "Intermediate",
        duration: "24 Hours",
        description: "Deploy, configure, and manage FortiGate firewalls. Implement firewall policies, authentication, and VPN.",
        highlights: ["FortiGate Deployment", "Firewall Policies", "User Authentication", "SSL & IPsec VPN"],
        certCode: "NSE 4",
        mode: ["Live Online", "Classroom"],
      },
      {
        id: "forti-nse7",
        title: "Fortinet NSE 7 — Enterprise Firewall",
        slug: "fortigate-enterprise",
        vendor: "Fortinet",
        vendorSlug: "fortinet",
        category: "Network Security",
        level: "Expert",
        duration: "24 Hours",
        description: "Deploy, manage, and troubleshoot FortiGate in complex enterprise network environments.",
        highlights: ["Advanced Routing", "HA Clustering", "Hardware Acceleration", "Diagnostics"],
        certCode: "NSE 7",
        mode: ["Live Online"],
      },
    ],
  },
  {
    name: "Palo Alto",
    slug: "palo-alto",
    color: "#FA582D",
    courses: [
      {
        id: "pa-pcnsa",
        title: "PCNSA — Palo Alto Certified Network Security Administrator",
        slug: "pcnsa",
        vendor: "Palo Alto",
        vendorSlug: "palo-alto",
        category: "Network Security",
        level: "Intermediate",
        duration: "32 Hours",
        description: "Configure and manage Palo Alto Networks next-generation firewalls. Security policies, NAT, App-ID, and threat prevention.",
        highlights: ["Next-Gen Firewall", "App-ID Technology", "Threat Prevention", "URL Filtering"],
        certCode: "PCNSA",
        mode: ["Live Online", "Classroom"],
      },
      {
        id: "pa-pcnse",
        title: "PCNSE — Palo Alto Certified Network Security Engineer",
        slug: "pcnse",
        vendor: "Palo Alto",
        vendorSlug: "palo-alto",
        category: "Network Security",
        level: "Expert",
        duration: "40 Hours",
        description: "Design, deploy, configure, maintain, and troubleshoot Palo Alto Networks implementations.",
        highlights: ["Advanced Deployment", "Panorama Management", "GlobalProtect", "High Availability"],
        certCode: "PCNSE",
        mode: ["Live Online"],
      },
    ],
  },
];

export const allCourses: Course[] = vendors.flatMap((v) => v.courses);

export const featuredCourses: Course[] = allCourses.filter((c) => c.featured);

export const testimonials: Testimonial[] = [
  {
    name: "Rajesh Kumar",
    role: "Network Security Engineer",
    company: "Infosys",
    quote: "GIT Academy transformed my career. The hands-on labs and expert instructors gave me the practical skills I needed to clear my CCNP Security on the first attempt.",
    rating: 5,
    course: "CCNP Security",
  },
  {
    name: "Priya Sharma",
    role: "SOC Analyst",
    company: "Wipro",
    quote: "The CEH v12 training was exceptional. The real-world attack simulations and 220+ labs prepared me for real SOC operations far better than any other program.",
    rating: 5,
    course: "CEH v12",
  },
  {
    name: "Arun Nair",
    role: "Cloud Security Architect",
    company: "TCS",
    quote: "Outstanding Azure Security training. The instructor's industry experience made complex concepts crystal clear. Passed AZ-500 with a score above 900.",
    rating: 5,
    course: "AZ-500",
  },
  {
    name: "Deepa Menon",
    role: "Penetration Tester",
    company: "HCLTech",
    quote: "The CPENT program at GIT Academy is unmatched. Real enterprise network environments for testing — something you won't find in any other training center in Bangalore.",
    rating: 5,
    course: "CPENT",
  },
  {
    name: "Vikram Singh",
    role: "IT Manager",
    company: "Cognizant",
    quote: "We enrolled our entire team for corporate training. The customized curriculum for our Cisco infrastructure was exactly what we needed. ROI was immediate.",
    rating: 5,
    course: "Corporate Training",
  },
  {
    name: "Sneha Patel",
    role: "Security Consultant",
    company: "Deloitte",
    quote: "From CompTIA Security+ to advanced Fortinet training — GIT Academy has been my go-to for every certification. The guaranteed-to-run schedule is a game changer.",
    rating: 5,
    course: "Security+",
  },
];

export const blogPosts: BlogPost[] = [
  {
    id: "1",
    title: "The Future of AI-Driven Cybersecurity: What Professionals Need to Know in 2026",
    slug: "ai-driven-cybersecurity-2026",
    excerpt: "As AI transforms the threat landscape, cybersecurity professionals must evolve. Explore the skills and certifications that matter most in the age of AI-powered attacks.",
    category: "Industry Trends",
    author: "GIT Academy",
    date: "2026-05-28",
    readTime: "8 min",
  },
  {
    id: "2",
    title: "CCNA vs Security+: Which Certification Should You Get First?",
    slug: "ccna-vs-security-plus",
    excerpt: "Two of the most popular entry-level certifications in IT. We break down the career paths, salary expectations, and learning curves to help you decide.",
    category: "Career Guides",
    author: "GIT Academy",
    date: "2026-05-20",
    readTime: "6 min",
  },
  {
    id: "3",
    title: "Building a Home Lab for Ethical Hacking: A Complete Guide",
    slug: "home-lab-ethical-hacking",
    excerpt: "Set up your own penetration testing lab with virtual machines, vulnerable targets, and professional tools — without spending a fortune.",
    category: "Tutorials",
    author: "GIT Academy",
    date: "2026-05-15",
    readTime: "12 min",
  },
];

export const navLinks = [
  {
    label: "Training",
    href: "/training",
    children: [
      { label: "Cisco", href: "/training?vendor=cisco", description: "CCNA, CCNP, CCIE tracks" },
      { label: "EC-Council", href: "/training?vendor=ec-council", description: "CEH, CHFI, CPENT" },
      { label: "CompTIA", href: "/training?vendor=comptia", description: "Security+, Network+, CySA+" },
      { label: "Microsoft Azure", href: "/training?vendor=microsoft", description: "AZ-900, AZ-104, AZ-500" },
      { label: "AWS", href: "/training?vendor=aws", description: "Solutions Architect, Security" },
      { label: "Fortinet", href: "/training?vendor=fortinet", description: "NSE 4, NSE 7" },
      { label: "Palo Alto", href: "/training?vendor=palo-alto", description: "PCNSA, PCNSE" },
    ],
  },
  { label: "Certifications", href: "/certifications" },
  { label: "Virtual Labs", href: "/labs" },
  { label: "Corporate", href: "/corporate" },
  { label: "About", href: "/about" },
  { label: "Blog", href: "/blog" },
  { label: "Contact", href: "/contact" },
];

export const stats = [
  { value: 10000, suffix: "+", label: "Professionals Trained" },
  { value: 95, suffix: "%", label: "Certification Pass Rate" },
  { value: 200, suffix: "+", label: "Training Programs" },
  { value: 20, suffix: "+", label: "Years of Excellence" },
];

export const partnerLogos = [
  "Cisco", "EC-Council", "CompTIA", "Microsoft", "AWS", "Fortinet",
  "Palo Alto", "Red Hat", "Juniper", "Google Cloud", "ITIL", "CertNexus",
];
