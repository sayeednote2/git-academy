'use client';

import { useState } from 'react';
import { motion, AnimatePresence } from 'framer-motion';
import { Clock, User, ArrowRight, Tag } from 'lucide-react';
import { blogPosts as importedPosts } from '@/lib/data';
import Link from 'next/link';

const additionalPosts = [
  {
    id: '4',
    title: 'Zero Trust Architecture: A Practical Implementation Guide for 2026',
    slug: 'zero-trust-architecture-guide',
    excerpt:
      'Zero Trust is no longer a buzzword — it\'s a requirement. Learn how to implement ZTA principles across your organization with actionable steps and tool recommendations.',
    category: 'Industry Trends',
    author: 'GIT Academy',
    date: '2026-05-10',
    readTime: '10 min',
  },
  {
    id: '5',
    title: 'From CCNA to CCIE: The Complete Cisco Certification Roadmap',
    slug: 'cisco-certification-roadmap',
    excerpt:
      'Planning your Cisco career path? We break down every certification tier, study timelines, costs, and the best order to tackle them for maximum career impact.',
    category: 'Career Guides',
    author: 'GIT Academy',
    date: '2026-05-05',
    readTime: '9 min',
  },
  {
    id: '6',
    title: 'Top 10 CEH v12 Exam Tips from Certified Ethical Hackers',
    slug: 'ceh-v12-exam-tips',
    excerpt:
      'Ace your CEH v12 exam with insider tips from our instructors who have trained 2,000+ ethical hackers. Study strategies, lab practice advice, and common pitfalls to avoid.',
    category: 'Certifications',
    author: 'GIT Academy',
    date: '2026-04-28',
    readTime: '7 min',
  },
];

const allBlogPosts = [...importedPosts, ...additionalPosts];

const categories = ['All', 'Industry Trends', 'Career Guides', 'Tutorials', 'Certifications'];

const categoryColors: Record<string, string> = {
  'Industry Trends': 'bg-accent-cyan/15 text-accent-cyan border-accent-cyan/30',
  'Career Guides': 'bg-accent-purple/15 text-accent-purple border-accent-purple/30',
  'Tutorials': 'bg-accent-green/15 text-accent-green border-accent-green/30',
  'Certifications': 'bg-accent-amber/15 text-accent-amber border-accent-amber/30',
};

function formatDate(dateStr: string) {
  return new Date(dateStr).toLocaleDateString('en-US', {
    year: 'numeric',
    month: 'long',
    day: 'numeric',
  });
}

export default function BlogPage() {
  const [activeCategory, setActiveCategory] = useState('All');

  const filteredPosts = allBlogPosts.filter(
    (post) => activeCategory === 'All' || post.category === activeCategory
  );

  return (
    <div className="min-h-screen bg-bg-primary">
      {/* Hero */}
      <section className="relative py-24 lg:py-32 overflow-hidden">
        <div className="absolute inset-0 cyber-grid" />
        <div className="absolute inset-0 bg-gradient-to-b from-accent-cyan/5 via-transparent to-transparent" />
        <div className="relative max-w-7xl mx-auto px-6">
          <motion.div
            initial={{ opacity: 0, y: 30 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.7, ease: [0.16, 1, 0.3, 1] }}
            className="text-center max-w-3xl mx-auto"
          >
            <div className="inline-flex items-center gap-2 px-4 py-1.5 rounded-full border border-border-subtle bg-bg-secondary/50 backdrop-blur-sm mb-6">
              <span className="w-1.5 h-1.5 rounded-full bg-accent-cyan animate-pulse" />
              <span className="text-sm text-text-secondary font-medium">
                Knowledge Base
              </span>
            </div>
            <h1 className="text-4xl md:text-5xl lg:text-6xl font-bold text-text-primary mb-6 tracking-tight">
              Cybersecurity{' '}
              <span className="gradient-text-cyan">Insights</span>
            </h1>
            <p className="text-lg text-text-secondary leading-relaxed max-w-2xl mx-auto">
              Expert analysis, career guides, and technical tutorials from GIT
              Academy&apos;s team of certified instructors and industry practitioners.
            </p>
          </motion.div>
        </div>
      </section>

      {/* Category Filters */}
      <section className="py-8">
        <div className="max-w-7xl mx-auto px-6">
          <motion.div
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.5, delay: 0.2 }}
            className="flex flex-wrap gap-2 mb-12"
          >
            {categories.map((category) => (
              <button
                key={category}
                onClick={() => setActiveCategory(category)}
                className={`px-5 py-2.5 rounded-xl text-sm font-medium transition-all duration-300 border ${
                  activeCategory === category
                    ? 'bg-accent-cyan/15 border-accent-cyan/40 text-accent-cyan shadow-[0_0_20px_rgba(0,229,255,0.1)]'
                    : 'bg-bg-secondary/50 border-border-subtle text-text-secondary hover:text-text-primary hover:border-border-hover'
                }`}
              >
                {category}
              </button>
            ))}
          </motion.div>

          {/* Results Count */}
          <div className="mb-8">
            <p className="text-sm text-text-muted">
              <span className="text-text-primary font-medium">
                {filteredPosts.length}
              </span>{' '}
              {filteredPosts.length === 1 ? 'article' : 'articles'}
              {activeCategory !== 'All' && (
                <>
                  {' '}in{' '}
                  <span className="text-accent-cyan">{activeCategory}</span>
                </>
              )}
            </p>
          </div>

          {/* Blog Grid */}
          <motion.div
            layout
            className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6"
          >
            <AnimatePresence mode="popLayout">
              {filteredPosts.map((post, index) => (
                <motion.article
                  key={post.id}
                  layout
                  initial={{ opacity: 0, scale: 0.95, y: 20 }}
                  animate={{ opacity: 1, scale: 1, y: 0 }}
                  exit={{ opacity: 0, scale: 0.95, y: -10 }}
                  transition={{
                    duration: 0.4,
                    delay: index * 0.05,
                    ease: [0.16, 1, 0.3, 1],
                  }}
                >
                  <Link
                    href={`/blog/${post.slug}`}
                    className="group block glass glass-hover rounded-2xl p-6 h-full flex flex-col"
                  >
                    {/* Category Badge */}
                    <div className="flex items-center justify-between mb-4">
                      <span
                        className={`inline-flex items-center gap-1.5 text-xs font-medium px-2.5 py-1 rounded-md border ${
                          categoryColors[post.category] || 'bg-bg-tertiary/60 text-text-muted border-border-subtle'
                        }`}
                      >
                        <Tag className="w-3 h-3" />
                        {post.category}
                      </span>
                      <span className="flex items-center gap-1 text-xs text-text-muted">
                        <Clock className="w-3 h-3" />
                        {post.readTime}
                      </span>
                    </div>

                    {/* Title */}
                    <h3 className="text-lg font-semibold text-text-primary mb-3 group-hover:text-accent-cyan transition-colors duration-300 leading-snug">
                      {post.title}
                    </h3>

                    {/* Excerpt */}
                    <p className="text-sm text-text-secondary leading-relaxed mb-5 line-clamp-3 flex-grow">
                      {post.excerpt}
                    </p>

                    {/* Footer */}
                    <div className="flex items-center justify-between pt-4 border-t border-border-subtle">
                      <div className="flex items-center gap-2">
                        <div className="w-6 h-6 rounded-full bg-accent-cyan/15 flex items-center justify-center">
                          <User className="w-3 h-3 text-accent-cyan" />
                        </div>
                        <div className="text-xs">
                          <span className="text-text-secondary">{post.author}</span>
                          <span className="text-text-muted mx-1.5">·</span>
                          <span className="text-text-muted">{formatDate(post.date)}</span>
                        </div>
                      </div>
                      <ArrowRight className="w-4 h-4 text-text-muted group-hover:text-accent-cyan group-hover:translate-x-1 transition-all duration-300" />
                    </div>
                  </Link>
                </motion.article>
              ))}
            </AnimatePresence>
          </motion.div>

          {/* Empty State */}
          {filteredPosts.length === 0 && (
            <motion.div
              initial={{ opacity: 0 }}
              animate={{ opacity: 1 }}
              className="text-center py-20"
            >
              <p className="text-text-secondary text-lg">
                No articles found in this category.
              </p>
              <button
                onClick={() => setActiveCategory('All')}
                className="mt-4 text-accent-cyan hover:text-white transition-colors text-sm"
              >
                View all articles
              </button>
            </motion.div>
          )}
        </div>
      </section>

      {/* Newsletter CTA */}
      <section className="py-24 lg:py-32">
        <div className="max-w-7xl mx-auto px-6">
          <motion.div
            initial={{ opacity: 0, y: 30 }}
            whileInView={{ opacity: 1, y: 0 }}
            viewport={{ once: true, margin: '-100px' }}
            transition={{ duration: 0.7 }}
            className="glass rounded-2xl p-12 lg:p-16 text-center relative overflow-hidden"
          >
            <div className="absolute inset-0 bg-gradient-to-br from-accent-cyan/5 via-transparent to-accent-purple/5" />
            <div className="relative">
              <h2 className="text-2xl lg:text-3xl font-bold text-text-primary mb-4">
                Stay Ahead of the Curve
              </h2>
              <p className="text-text-secondary max-w-xl mx-auto mb-8">
                Get the latest cybersecurity insights, certification guides, and
                training updates delivered to your inbox.
              </p>
              <div className="flex flex-col sm:flex-row items-center justify-center gap-3 max-w-md mx-auto">
                <input
                  type="email"
                  placeholder="Enter your email"
                  className="w-full px-4 py-3.5 rounded-xl bg-bg-secondary/80 border border-border-subtle text-text-primary placeholder:text-text-muted text-sm focus:outline-none focus:border-accent-cyan/40 transition-colors"
                />
                <button className="w-full sm:w-auto inline-flex items-center justify-center gap-2 px-8 py-3.5 rounded-xl bg-accent-cyan text-bg-primary font-semibold text-sm hover:bg-accent-cyan/90 transition-all duration-300 hover:shadow-[0_0_30px_rgba(0,229,255,0.3)] whitespace-nowrap">
                  Subscribe
                </button>
              </div>
            </div>
          </motion.div>
        </div>
      </section>
    </div>
  );
}
