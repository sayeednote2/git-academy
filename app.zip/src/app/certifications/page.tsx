'use client';

import { motion } from 'framer-motion';
import { ArrowRight, Shield, Cloud, Network, ChevronRight } from 'lucide-react';
import { vendors, allCourses } from '@/lib/data';
import Link from 'next/link';

const levels = ['Beginner', 'Intermediate', 'Advanced', 'Expert'] as const;

const levelMeta: Record<string, { color: string; glow: string; label: string; description: string }> = {
  Beginner: {
    color: 'border-accent-green/40 bg-accent-green/10',
    glow: 'shadow-[0_0_20px_rgba(16,185,129,0.08)]',
    label: 'Foundation',
    description: 'Build core knowledge and fundamental skills',
  },
  Intermediate: {
    color: 'border-accent-cyan/40 bg-accent-cyan/10',
    glow: 'shadow-[0_0_20px_rgba(0,229,255,0.08)]',
    label: 'Professional',
    description: 'Develop specialized expertise and practical skills',
  },
  Advanced: {
    color: 'border-accent-purple/40 bg-accent-purple/10',
    glow: 'shadow-[0_0_20px_rgba(124,58,237,0.08)]',
    label: 'Specialist',
    description: 'Master complex technologies and architectures',
  },
  Expert: {
    color: 'border-accent-red/40 bg-accent-red/10',
    glow: 'shadow-[0_0_20px_rgba(255,59,92,0.08)]',
    label: 'Expert',
    description: 'Lead and architect at the highest level',
  },
};

const levelBadgeColors: Record<string, string> = {
  Beginner: 'text-accent-green',
  Intermediate: 'text-accent-cyan',
  Advanced: 'text-accent-purple',
  Expert: 'text-accent-red',
};

const careerTracks = [
  {
    title: 'Network Engineering',
    icon: Network,
    gradient: 'from-accent-cyan/20 to-accent-cyan/5',
    borderColor: 'border-accent-cyan/30',
    certs: [
      { name: 'CompTIA Network+', code: 'N10-009', vendor: 'CompTIA' },
      { name: 'CCNA', code: '200-301', vendor: 'Cisco' },
      { name: 'ENCOR', code: '350-401', vendor: 'Cisco' },
      { name: 'Cisco SD-WAN', code: '300-415', vendor: 'Cisco' },
    ],
  },
  {
    title: 'Cybersecurity',
    icon: Shield,
    gradient: 'from-accent-purple/20 to-accent-purple/5',
    borderColor: 'border-accent-purple/30',
    certs: [
      { name: 'CompTIA Security+', code: 'SY0-701', vendor: 'CompTIA' },
      { name: 'CEH v12', code: '312-50', vendor: 'EC-Council' },
      { name: 'CySA+', code: 'CS0-003', vendor: 'CompTIA' },
      { name: 'CPENT', code: '', vendor: 'EC-Council' },
    ],
  },
  {
    title: 'Cloud Security',
    icon: Cloud,
    gradient: 'from-accent-amber/20 to-accent-amber/5',
    borderColor: 'border-accent-amber/30',
    certs: [
      { name: 'AZ-900 Fundamentals', code: 'AZ-900', vendor: 'Microsoft' },
      { name: 'AWS Solutions Architect', code: 'SAA-C03', vendor: 'AWS' },
      { name: 'AZ-500 Security Engineer', code: 'AZ-500', vendor: 'Microsoft' },
      { name: 'AWS Security Specialty', code: 'SCS-C02', vendor: 'AWS' },
    ],
  },
];

const vendorColorMap: Record<string, string> = {};
vendors.forEach((v) => {
  vendorColorMap[v.slug] = v.color;
});

export default function CertificationsPage() {
  const coursesByLevel = levels.map((level) => ({
    level,
    courses: allCourses.filter((c) => c.level === level),
  }));

  return (
    <div className="min-h-screen bg-bg-primary">
      {/* Hero */}
      <section className="relative py-24 lg:py-32 overflow-hidden">
        <div className="absolute inset-0 cyber-grid" />
        <div className="absolute inset-0 bg-gradient-to-b from-accent-purple/5 via-transparent to-transparent" />
        <div className="relative max-w-7xl mx-auto px-6">
          <motion.div
            initial={{ opacity: 0, y: 30 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.7, ease: [0.16, 1, 0.3, 1] }}
            className="text-center max-w-3xl mx-auto"
          >
            <div className="inline-flex items-center gap-2 px-4 py-1.5 rounded-full border border-border-subtle bg-bg-secondary/50 backdrop-blur-sm mb-6">
              <span className="w-1.5 h-1.5 rounded-full bg-accent-purple animate-pulse" />
              <span className="text-sm text-text-secondary font-medium">
                Structured Learning Paths
              </span>
            </div>
            <h1 className="text-4xl md:text-5xl lg:text-6xl font-bold text-text-primary mb-6 tracking-tight">
              Certification{' '}
              <span className="gradient-text">Pathways</span>
            </h1>
            <p className="text-lg text-text-secondary leading-relaxed max-w-2xl mx-auto">
              Navigate your cybersecurity career with structured certification
              roadmaps. From foundational knowledge to expert-level mastery — every
              step is mapped for you.
            </p>
          </motion.div>
        </div>
      </section>

      {/* Certification Roadmap */}
      <section className="py-24 lg:py-32 relative">
        <div className="max-w-7xl mx-auto px-6">
          <motion.div
            initial={{ opacity: 0, y: 20 }}
            whileInView={{ opacity: 1, y: 0 }}
            viewport={{ once: true, margin: '-100px' }}
            transition={{ duration: 0.6 }}
            className="text-center mb-16"
          >
            <h2 className="text-3xl lg:text-4xl font-bold text-text-primary mb-4">
              Progression Roadmap
            </h2>
            <p className="text-text-secondary max-w-xl mx-auto">
              Follow the path from beginner to expert across all vendor certifications
            </p>
          </motion.div>

          {/* Level progression indicator */}
          <div className="hidden lg:flex items-center justify-center gap-0 mb-16">
            {levels.map((level, idx) => (
              <div key={level} className="flex items-center">
                <motion.div
                  initial={{ opacity: 0, scale: 0.8 }}
                  whileInView={{ opacity: 1, scale: 1 }}
                  viewport={{ once: true }}
                  transition={{ duration: 0.5, delay: idx * 0.15 }}
                  className={`flex items-center gap-3 px-6 py-3 rounded-xl border ${levelMeta[level].color} ${levelMeta[level].glow}`}
                >
                  <span className={`text-sm font-bold ${levelBadgeColors[level]}`}>
                    {levelMeta[level].label}
                  </span>
                </motion.div>
                {idx < levels.length - 1 && (
                  <div className="flex items-center px-2">
                    <div className="w-12 h-px bg-gradient-to-r from-border-subtle to-border-hover" />
                    <ChevronRight className="w-4 h-4 text-text-muted -ml-1" />
                  </div>
                )}
              </div>
            ))}
          </div>

          {/* Roadmap Grid by Level */}
          <div className="space-y-16">
            {coursesByLevel.map(({ level, courses }, levelIdx) => (
              <motion.div
                key={level}
                initial={{ opacity: 0, y: 30 }}
                whileInView={{ opacity: 1, y: 0 }}
                viewport={{ once: true, margin: '-50px' }}
                transition={{ duration: 0.6, delay: levelIdx * 0.1 }}
              >
                {/* Level Header */}
                <div className="flex items-center gap-4 mb-8">
                  <div
                    className={`w-12 h-12 rounded-xl flex items-center justify-center text-lg font-bold border ${levelMeta[level].color}`}
                  >
                    <span className={levelBadgeColors[level]}>
                      {levelIdx + 1}
                    </span>
                  </div>
                  <div>
                    <h3 className={`text-xl font-bold ${levelBadgeColors[level]}`}>
                      {levelMeta[level].label} — {level}
                    </h3>
                    <p className="text-sm text-text-muted">
                      {levelMeta[level].description}
                    </p>
                  </div>
                  <div className="hidden md:block ml-auto">
                    <span className="text-xs text-text-muted px-3 py-1 rounded-full border border-border-subtle">
                      {courses.length} {courses.length === 1 ? 'certification' : 'certifications'}
                    </span>
                  </div>
                </div>

                {/* Certs Grid */}
                <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 xl:grid-cols-4 gap-4">
                  {courses.map((course, i) => (
                    <motion.div
                      key={course.id}
                      initial={{ opacity: 0, y: 10 }}
                      whileInView={{ opacity: 1, y: 0 }}
                      viewport={{ once: true }}
                      transition={{ duration: 0.4, delay: i * 0.05 }}
                    >
                      <Link
                        href={`/training/${course.vendorSlug}/${course.slug}`}
                        className={`group block glass glass-hover rounded-xl p-5 h-full border-l-2`}
                        style={{
                          borderLeftColor:
                            vendorColorMap[course.vendorSlug] || '#00E5FF',
                        }}
                      >
                        <div className="flex items-start justify-between mb-3">
                          <span
                            className="text-xs font-semibold px-2 py-0.5 rounded"
                            style={{
                              color: vendorColorMap[course.vendorSlug] || '#00E5FF',
                              backgroundColor: `${vendorColorMap[course.vendorSlug] || '#00E5FF'}15`,
                            }}
                          >
                            {course.vendor}
                          </span>
                          {course.certCode && (
                            <span className="text-xs font-mono text-text-muted">
                              {course.certCode}
                            </span>
                          )}
                        </div>
                        <h3 className="text-sm font-semibold text-text-primary group-hover:text-accent-cyan transition-colors duration-300 mb-2 leading-snug">
                          {course.title}
                        </h3>
                        <div className="flex items-center gap-3 text-xs text-text-muted">
                          <span>{course.duration}</span>
                          <span className="w-1 h-1 rounded-full bg-text-muted" />
                          <span>{course.category}</span>
                        </div>
                      </Link>
                    </motion.div>
                  ))}
                </div>
              </motion.div>
            ))}
          </div>
        </div>
      </section>

      {/* Career Tracks */}
      <section className="py-24 lg:py-32 bg-bg-secondary/30">
        <div className="max-w-7xl mx-auto px-6">
          <motion.div
            initial={{ opacity: 0, y: 20 }}
            whileInView={{ opacity: 1, y: 0 }}
            viewport={{ once: true, margin: '-100px' }}
            transition={{ duration: 0.6 }}
            className="text-center mb-16"
          >
            <h2 className="text-3xl lg:text-4xl font-bold text-text-primary mb-4">
              Choose Your Path
            </h2>
            <p className="text-text-secondary max-w-xl mx-auto">
              Three proven career tracks with recommended certifications in sequential
              order
            </p>
          </motion.div>

          <div className="grid grid-cols-1 lg:grid-cols-3 gap-8">
            {careerTracks.map((track, idx) => (
              <motion.div
                key={track.title}
                initial={{ opacity: 0, y: 30 }}
                whileInView={{ opacity: 1, y: 0 }}
                viewport={{ once: true, margin: '-50px' }}
                transition={{ duration: 0.6, delay: idx * 0.15 }}
                className={`glass glass-hover rounded-2xl overflow-hidden border ${track.borderColor}`}
              >
                {/* Track Header */}
                <div
                  className={`p-8 bg-gradient-to-br ${track.gradient}`}
                >
                  <track.icon className="w-10 h-10 text-text-primary mb-4" />
                  <h3 className="text-xl font-bold text-text-primary">
                    {track.title}
                  </h3>
                </div>

                {/* Cert Steps */}
                <div className="p-6">
                  <div className="space-y-0">
                    {track.certs.map((cert, certIdx) => (
                      <div key={cert.name} className="relative">
                        {/* Connector line */}
                        {certIdx < track.certs.length - 1 && (
                          <div className="absolute left-[15px] top-[36px] w-px h-[calc(100%-10px)] bg-border-subtle" />
                        )}
                        <div className="flex items-start gap-4 py-3">
                          {/* Step number */}
                          <div className="w-8 h-8 rounded-lg bg-bg-tertiary border border-border-subtle flex items-center justify-center flex-shrink-0 text-xs font-bold text-text-secondary relative z-10">
                            {certIdx + 1}
                          </div>
                          <div className="flex-1 min-w-0">
                            <p className="text-sm font-semibold text-text-primary leading-snug">
                              {cert.name}
                            </p>
                            <div className="flex items-center gap-2 mt-1">
                              <span className="text-xs text-text-muted">
                                {cert.vendor}
                              </span>
                              {cert.code && (
                                <>
                                  <span className="w-1 h-1 rounded-full bg-text-muted" />
                                  <span className="text-xs font-mono text-text-muted">
                                    {cert.code}
                                  </span>
                                </>
                              )}
                            </div>
                          </div>
                        </div>
                      </div>
                    ))}
                  </div>
                </div>
              </motion.div>
            ))}
          </div>
        </div>
      </section>

      {/* CTA */}
      <section className="py-24 lg:py-32">
        <div className="max-w-7xl mx-auto px-6">
          <motion.div
            initial={{ opacity: 0, y: 30 }}
            whileInView={{ opacity: 1, y: 0 }}
            viewport={{ once: true, margin: '-100px' }}
            transition={{ duration: 0.7 }}
            className="glass rounded-2xl p-12 lg:p-16 text-center relative overflow-hidden"
          >
            <div className="absolute inset-0 bg-gradient-to-br from-accent-purple/5 via-transparent to-accent-cyan/5" />
            <div className="relative">
              <h2 className="text-2xl lg:text-3xl font-bold text-text-primary mb-4">
                Ready to start your certification journey?
              </h2>
              <p className="text-text-secondary max-w-xl mx-auto mb-8">
                Schedule a free consultation with our training advisors to build your
                personalized certification roadmap.
              </p>
              <Link
                href="/contact"
                className="inline-flex items-center gap-2 px-8 py-3.5 rounded-xl bg-accent-cyan text-bg-primary font-semibold text-sm hover:bg-accent-cyan/90 transition-all duration-300 hover:shadow-[0_0_30px_rgba(0,229,255,0.3)]"
              >
                Get Started
                <ArrowRight className="w-4 h-4" />
              </Link>
            </div>
          </motion.div>
        </div>
      </section>
    </div>
  );
}
