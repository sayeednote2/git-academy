'use client';

import { useState } from 'react';
import { motion, AnimatePresence } from 'framer-motion';
import { Clock, Monitor, GraduationCap, ArrowRight, Search } from 'lucide-react';
import { allCourses, vendors } from '@/lib/data';
import Link from 'next/link';

const vendorFilters = [
  { label: 'All', slug: 'all' },
  ...vendors.map((v) => ({ label: v.name, slug: v.slug })),
];

const levelColors: Record<string, string> = {
  Beginner: 'bg-accent-green/15 text-accent-green border-accent-green/30',
  Intermediate: 'bg-accent-cyan/15 text-accent-cyan border-accent-cyan/30',
  Advanced: 'bg-accent-purple/15 text-accent-purple border-accent-purple/30',
  Expert: 'bg-accent-red/15 text-accent-red border-accent-red/30',
};

const vendorDotColors: Record<string, string> = {};
vendors.forEach((v) => {
  vendorDotColors[v.slug] = v.color;
});

export default function TrainingPage() {
  const [activeVendor, setActiveVendor] = useState('all');
  const [searchQuery, setSearchQuery] = useState('');

  const filteredCourses = allCourses.filter((course) => {
    const matchesVendor =
      activeVendor === 'all' || course.vendorSlug === activeVendor;
    const matchesSearch =
      searchQuery === '' ||
      course.title.toLowerCase().includes(searchQuery.toLowerCase()) ||
      course.description.toLowerCase().includes(searchQuery.toLowerCase()) ||
      course.category.toLowerCase().includes(searchQuery.toLowerCase());
    return matchesVendor && matchesSearch;
  });

  return (
    <div className="min-h-screen bg-bg-primary">
      {/* Hero Section */}
      <section className="relative py-24 lg:py-32 overflow-hidden">
        <div className="absolute inset-0 cyber-grid" />
        <div className="absolute inset-0 bg-gradient-to-b from-accent-cyan/5 via-transparent to-transparent" />
        <div className="relative max-w-7xl mx-auto px-6">
          <motion.div
            initial={{ opacity: 0, y: 30 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.7, ease: [0.16, 1, 0.3, 1] }}
            className="text-center max-w-3xl mx-auto"
          >
            <div className="inline-flex items-center gap-2 px-4 py-1.5 rounded-full border border-border-subtle bg-bg-secondary/50 backdrop-blur-sm mb-6">
              <span className="w-1.5 h-1.5 rounded-full bg-accent-cyan animate-pulse" />
              <span className="text-sm text-text-secondary font-medium">
                200+ Training Programs
              </span>
            </div>
            <h1 className="text-4xl md:text-5xl lg:text-6xl font-bold text-text-primary mb-6 tracking-tight">
              Training{' '}
              <span className="gradient-text-cyan">Programs</span>
            </h1>
            <p className="text-lg text-text-secondary leading-relaxed max-w-2xl mx-auto">
              Explore our comprehensive catalog of industry-recognized certification
              courses. From foundational networking to advanced penetration testing —
              find the program that accelerates your career.
            </p>
          </motion.div>
        </div>
      </section>

      {/* Filter + Search Section */}
      <section className="relative py-8">
        <div className="max-w-7xl mx-auto px-6">
          {/* Search Bar */}
          <motion.div
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.5, delay: 0.2 }}
            className="mb-8"
          >
            <div className="relative max-w-md mx-auto lg:mx-0">
              <Search className="absolute left-4 top-1/2 -translate-y-1/2 w-4 h-4 text-text-muted" />
              <input
                type="text"
                placeholder="Search courses, vendors, categories..."
                value={searchQuery}
                onChange={(e) => setSearchQuery(e.target.value)}
                className="w-full pl-11 pr-4 py-3 rounded-xl bg-bg-secondary/80 border border-border-subtle text-text-primary placeholder:text-text-muted text-sm focus:outline-none focus:border-accent-cyan/40 transition-colors"
              />
            </div>
          </motion.div>

          {/* Vendor Filter Tabs */}
          <motion.div
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.5, delay: 0.3 }}
            className="flex flex-wrap gap-2 mb-12"
          >
            {vendorFilters.map((filter) => (
              <button
                key={filter.slug}
                onClick={() => setActiveVendor(filter.slug)}
                className={`px-5 py-2.5 rounded-xl text-sm font-medium transition-all duration-300 border ${
                  activeVendor === filter.slug
                    ? 'bg-accent-cyan/15 border-accent-cyan/40 text-accent-cyan shadow-[0_0_20px_rgba(0,229,255,0.1)]'
                    : 'bg-bg-secondary/50 border-border-subtle text-text-secondary hover:text-text-primary hover:border-border-hover'
                }`}
              >
                {filter.label}
              </button>
            ))}
          </motion.div>

          {/* Results Count */}
          <div className="mb-6">
            <p className="text-sm text-text-muted">
              Showing{' '}
              <span className="text-text-primary font-medium">
                {filteredCourses.length}
              </span>{' '}
              {filteredCourses.length === 1 ? 'course' : 'courses'}
              {activeVendor !== 'all' && (
                <>
                  {' '}in{' '}
                  <span className="text-accent-cyan">
                    {vendorFilters.find((f) => f.slug === activeVendor)?.label}
                  </span>
                </>
              )}
            </p>
          </div>

          {/* Course Grid */}
          <motion.div
            layout
            className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6"
          >
            <AnimatePresence mode="popLayout">
              {filteredCourses.map((course, index) => (
                <motion.div
                  key={course.id}
                  layout
                  initial={{ opacity: 0, scale: 0.95, y: 20 }}
                  animate={{ opacity: 1, scale: 1, y: 0 }}
                  exit={{ opacity: 0, scale: 0.95, y: -10 }}
                  transition={{
                    duration: 0.4,
                    delay: index * 0.03,
                    ease: [0.16, 1, 0.3, 1],
                  }}
                >
                  <div className="group glass glass-hover rounded-2xl p-6 h-full flex flex-col">
                    {/* Vendor + Category */}
                    <div className="flex items-center justify-between mb-4">
                      <div className="flex items-center gap-2">
                        <span
                          className="w-2.5 h-2.5 rounded-full flex-shrink-0"
                          style={{
                            backgroundColor:
                              vendorDotColors[course.vendorSlug] || '#00E5FF',
                          }}
                        />
                        <span className="text-sm font-medium text-text-secondary">
                          {course.vendor}
                        </span>
                      </div>
                      <span className="text-xs text-text-muted px-2.5 py-1 rounded-md bg-bg-tertiary/60">
                        {course.category}
                      </span>
                    </div>

                    {/* Title */}
                    <h3 className="text-lg font-semibold text-text-primary mb-3 group-hover:text-accent-cyan transition-colors duration-300 leading-snug">
                      {course.title}
                    </h3>

                    {/* Description */}
                    <p className="text-sm text-text-secondary leading-relaxed mb-5 line-clamp-2 flex-grow">
                      {course.description}
                    </p>

                    {/* Meta Row */}
                    <div className="flex flex-wrap items-center gap-3 mb-5">
                      <span
                        className={`text-xs font-medium px-2.5 py-1 rounded-md border ${
                          levelColors[course.level]
                        }`}
                      >
                        {course.level}
                      </span>
                      <div className="flex items-center gap-1 text-xs text-text-muted">
                        <Clock className="w-3.5 h-3.5" />
                        <span>{course.duration}</span>
                      </div>
                      {course.certCode && (
                        <div className="flex items-center gap-1 text-xs text-text-muted font-mono">
                          <GraduationCap className="w-3.5 h-3.5" />
                          <span>{course.certCode}</span>
                        </div>
                      )}
                    </div>

                    {/* Delivery Modes */}
                    <div className="flex flex-wrap gap-1.5 mb-5">
                      {course.mode.map((mode) => (
                        <span
                          key={mode}
                          className="inline-flex items-center gap-1 text-xs text-text-muted px-2 py-0.5 rounded bg-bg-primary/50 border border-border-subtle"
                        >
                          <Monitor className="w-3 h-3" />
                          {mode}
                        </span>
                      ))}
                    </div>

                    {/* CTA */}
                    <Link
                      href={`/training/${course.vendorSlug}/${course.slug}`}
                      className="inline-flex items-center gap-2 text-sm font-medium text-accent-cyan hover:text-white transition-colors duration-300 group/link mt-auto"
                    >
                      Learn More
                      <ArrowRight className="w-4 h-4 group-hover/link:translate-x-1 transition-transform duration-300" />
                    </Link>
                  </div>
                </motion.div>
              ))}
            </AnimatePresence>
          </motion.div>

          {/* Empty State */}
          {filteredCourses.length === 0 && (
            <motion.div
              initial={{ opacity: 0 }}
              animate={{ opacity: 1 }}
              className="text-center py-20"
            >
              <p className="text-text-secondary text-lg">
                No courses found matching your criteria.
              </p>
              <button
                onClick={() => {
                  setActiveVendor('all');
                  setSearchQuery('');
                }}
                className="mt-4 text-accent-cyan hover:text-white transition-colors text-sm"
              >
                Clear filters
              </button>
            </motion.div>
          )}
        </div>
      </section>

      {/* CTA Section */}
      <section className="py-24 lg:py-32">
        <div className="max-w-7xl mx-auto px-6">
          <motion.div
            initial={{ opacity: 0, y: 30 }}
            whileInView={{ opacity: 1, y: 0 }}
            viewport={{ once: true, margin: '-100px' }}
            transition={{ duration: 0.7 }}
            className="glass rounded-2xl p-12 lg:p-16 text-center relative overflow-hidden"
          >
            <div className="absolute inset-0 bg-gradient-to-br from-accent-cyan/5 via-transparent to-accent-purple/5" />
            <div className="relative">
              <h2 className="text-2xl lg:text-3xl font-bold text-text-primary mb-4">
                Not sure which course is right for you?
              </h2>
              <p className="text-text-secondary max-w-xl mx-auto mb-8">
                Our training advisors can help you map the perfect certification path
                based on your experience level and career goals.
              </p>
              <Link
                href="/contact"
                className="inline-flex items-center gap-2 px-8 py-3.5 rounded-xl bg-accent-cyan text-bg-primary font-semibold text-sm hover:bg-accent-cyan/90 transition-all duration-300 hover:shadow-[0_0_30px_rgba(0,229,255,0.3)]"
              >
                Talk to an Advisor
                <ArrowRight className="w-4 h-4" />
              </Link>
            </div>
          </motion.div>
        </div>
      </section>
    </div>
  );
}
