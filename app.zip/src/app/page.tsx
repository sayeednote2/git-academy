import type { Metadata } from 'next';
import { HeroSection } from '@/components/home/HeroSection';
import { PartnerLogos } from '@/components/home/PartnerLogos';
import { WhySection } from '@/components/home/WhySection';
import { CourseShowcase } from '@/components/home/CourseShowcase';
import { StatsSection } from '@/components/home/StatsSection';
import { LabPreview } from '@/components/home/LabPreview';
import { TestimonialsSection } from '@/components/home/TestimonialsSection';
import { BlogPreview } from '@/components/home/BlogPreview';
import { CTASection } from '@/components/home/CTASection';

export const metadata: Metadata = {
  title: 'GIT Academy — Premier Cybersecurity Training & Certifications',
  description:
    'Master cybersecurity with world-class training from GIT Academy. Industry certifications from Cisco, EC-Council, CompTIA, Microsoft, AWS, and more. Hands-on labs, expert instructors, 95% pass rate. Established 2002, Bangalore.',
  openGraph: {
    title: 'GIT Academy — Premier Cybersecurity Training & Certifications',
    description:
      'Master cybersecurity with world-class training. Industry certifications, hands-on labs, expert instructors.',
    url: 'https://gitinfo.com',
  },
};

export default function HomePage() {
  return (
    <>
      <HeroSection />
      <PartnerLogos />
      <WhySection />
      <CourseShowcase />
      <StatsSection />
      <LabPreview />
      <TestimonialsSection />
      <BlogPreview />
      <CTASection />
    </>
  );
}
