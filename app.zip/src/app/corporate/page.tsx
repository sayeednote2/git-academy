'use client';

import { useState, useEffect, useRef } from 'react';
import { motion } from 'framer-motion';
import {
  Settings,
  Users,
  TrendingUp,
  ClipboardCheck,
  Palette,
  Truck,
  BarChart3,
  Monitor,
  MapPin,
  Layers,
  ArrowRight,
  ChevronRight,
} from 'lucide-react';
import Link from 'next/link';

const valueCards = [
  {
    icon: Palette,
    title: 'Custom Programs',
    description:
      'Tailored training curricula designed around your organization\'s technology stack, security posture, and team skill gaps.',
    color: 'text-accent-cyan',
    borderColor: 'border-accent-cyan/30',
  },
  {
    icon: Users,
    title: 'Team Upskilling',
    description:
      'Scale cybersecurity capabilities across your entire workforce — from SOC analysts to engineering leads.',
    color: 'text-accent-purple',
    borderColor: 'border-accent-purple/30',
  },
  {
    icon: TrendingUp,
    title: 'ROI Metrics',
    description:
      'Track learning outcomes with detailed analytics. Measure certification rates, skill progression, and security posture improvements.',
    color: 'text-accent-green',
    borderColor: 'border-accent-green/30',
  },
];

const processSteps = [
  {
    step: 1,
    title: 'Assess',
    description: 'Evaluate your team\'s current skills, identify gaps, and define learning objectives.',
    icon: ClipboardCheck,
  },
  {
    step: 2,
    title: 'Design',
    description: 'Build a customized training plan with vendor-specific courses and hands-on labs.',
    icon: Settings,
  },
  {
    step: 3,
    title: 'Deliver',
    description: 'Expert-led sessions delivered in your preferred format — on-site, virtual, or hybrid.',
    icon: Truck,
  },
  {
    step: 4,
    title: 'Measure',
    description: 'Track results with post-training assessments, certification rates, and progress reports.',
    icon: BarChart3,
  },
];

const trainingFormats = [
  {
    icon: Monitor,
    title: 'Instructor-Led',
    description: 'Live sessions with expert trainers in our Bangalore facility.',
    tag: 'Most Popular',
  },
  {
    icon: Layers,
    title: 'Virtual ILT',
    description: 'Live online sessions with screen sharing, breakout rooms, and real-time Q&A.',
    tag: 'Remote',
  },
  {
    icon: Settings,
    title: 'Hybrid',
    description: 'Blend of in-person and virtual sessions for distributed teams.',
    tag: 'Flexible',
  },
  {
    icon: MapPin,
    title: 'On-Site',
    description: 'Our instructors come to your office. Full training setup included.',
    tag: 'Enterprise',
  },
];

const metrics = [
  { value: 500, suffix: '+', label: 'Corporate Clients' },
  { value: 50, suffix: '+', label: 'Enterprise Partners' },
  { value: 100, suffix: '%', label: 'Customizable' },
];

function AnimatedCounter({ target, suffix }: { target: number; suffix: string }) {
  const [count, setCount] = useState(0);
  const ref = useRef<HTMLDivElement>(null);
  const hasAnimated = useRef(false);

  useEffect(() => {
    const observer = new IntersectionObserver(
      ([entry]) => {
        if (entry.isIntersecting && !hasAnimated.current) {
          hasAnimated.current = true;
          let start = 0;
          const duration = 2000;
          const increment = target / (duration / 16);
          const timer = setInterval(() => {
            start += increment;
            if (start >= target) {
              setCount(target);
              clearInterval(timer);
            } else {
              setCount(Math.floor(start));
            }
          }, 16);
        }
      },
      { threshold: 0.3 }
    );
    if (ref.current) observer.observe(ref.current);
    return () => observer.disconnect();
  }, [target]);

  return (
    <div ref={ref} className="text-4xl lg:text-5xl font-bold text-accent-cyan font-mono">
      {count}
      {suffix}
    </div>
  );
}

export default function CorporatePage() {
  return (
    <div className="min-h-screen bg-bg-primary">
      {/* Hero */}
      <section className="relative py-24 lg:py-32 overflow-hidden">
        <div className="absolute inset-0 cyber-grid" />
        <div className="absolute inset-0 bg-gradient-to-b from-accent-purple/5 via-transparent to-transparent" />
        <div className="relative max-w-7xl mx-auto px-6">
          <motion.div
            initial={{ opacity: 0, y: 30 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.7, ease: [0.16, 1, 0.3, 1] }}
            className="text-center max-w-3xl mx-auto"
          >
            <div className="inline-flex items-center gap-2 px-4 py-1.5 rounded-full border border-border-subtle bg-bg-secondary/50 backdrop-blur-sm mb-6">
              <span className="w-1.5 h-1.5 rounded-full bg-accent-purple animate-pulse" />
              <span className="text-sm text-text-secondary font-medium">
                Enterprise Solutions
              </span>
            </div>
            <h1 className="text-4xl md:text-5xl lg:text-6xl font-bold text-text-primary mb-6 tracking-tight">
              Enterprise Cybersecurity{' '}
              <span className="gradient-text">Training</span>
            </h1>
            <p className="text-lg text-text-secondary leading-relaxed max-w-2xl mx-auto">
              Upskill your workforce with customized training programs from
              authorized Cisco, Microsoft, AWS, and EC-Council partners. From needs
              assessment to certification — we handle everything.
            </p>
          </motion.div>
        </div>
      </section>

      {/* Value Cards */}
      <section className="py-24 lg:py-32">
        <div className="max-w-7xl mx-auto px-6">
          <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
            {valueCards.map((card, idx) => (
              <motion.div
                key={card.title}
                initial={{ opacity: 0, y: 30 }}
                whileInView={{ opacity: 1, y: 0 }}
                viewport={{ once: true, margin: '-50px' }}
                transition={{ duration: 0.6, delay: idx * 0.12 }}
                className={`glass glass-hover rounded-2xl p-8 border-t-2 ${card.borderColor}`}
              >
                <div className="w-12 h-12 rounded-xl bg-bg-tertiary border border-border-subtle flex items-center justify-center mb-6">
                  <card.icon className={`w-6 h-6 ${card.color}`} />
                </div>
                <h3 className="text-xl font-bold text-text-primary mb-3">
                  {card.title}
                </h3>
                <p className="text-sm text-text-secondary leading-relaxed">
                  {card.description}
                </p>
              </motion.div>
            ))}
          </div>
        </div>
      </section>

      {/* How It Works */}
      <section className="py-24 lg:py-32 bg-bg-secondary/30">
        <div className="max-w-7xl mx-auto px-6">
          <motion.div
            initial={{ opacity: 0, y: 20 }}
            whileInView={{ opacity: 1, y: 0 }}
            viewport={{ once: true, margin: '-100px' }}
            transition={{ duration: 0.6 }}
            className="text-center mb-16"
          >
            <h2 className="text-3xl lg:text-4xl font-bold text-text-primary mb-4">
              How It Works
            </h2>
            <p className="text-text-secondary max-w-xl mx-auto">
              A proven four-step process to transform your team&apos;s cybersecurity capabilities
            </p>
          </motion.div>

          <div className="relative">
            {/* Connector line — desktop */}
            <div className="hidden lg:block absolute top-[60px] left-[calc(12.5%+24px)] right-[calc(12.5%+24px)] h-px bg-gradient-to-r from-accent-cyan/20 via-accent-purple/20 to-accent-cyan/20" />

            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-8">
              {processSteps.map((step, idx) => (
                <motion.div
                  key={step.title}
                  initial={{ opacity: 0, y: 30 }}
                  whileInView={{ opacity: 1, y: 0 }}
                  viewport={{ once: true }}
                  transition={{ duration: 0.6, delay: idx * 0.15 }}
                  className="relative text-center"
                >
                  {/* Step Number */}
                  <div className="relative inline-flex items-center justify-center w-16 h-16 rounded-2xl glass border border-accent-cyan/20 mb-6 z-10">
                    <span className="text-xl font-bold text-accent-cyan font-mono">
                      {String(step.step).padStart(2, '0')}
                    </span>
                  </div>

                  {/* Arrow between steps — mobile */}
                  {idx < processSteps.length - 1 && (
                    <div className="lg:hidden flex justify-center my-2">
                      <ChevronRight className="w-5 h-5 text-text-muted rotate-90" />
                    </div>
                  )}

                  <h3 className="text-lg font-bold text-text-primary mb-2">
                    {step.title}
                  </h3>
                  <p className="text-sm text-text-secondary leading-relaxed">
                    {step.description}
                  </p>
                </motion.div>
              ))}
            </div>
          </div>
        </div>
      </section>

      {/* Training Formats */}
      <section className="py-24 lg:py-32">
        <div className="max-w-7xl mx-auto px-6">
          <motion.div
            initial={{ opacity: 0, y: 20 }}
            whileInView={{ opacity: 1, y: 0 }}
            viewport={{ once: true, margin: '-100px' }}
            transition={{ duration: 0.6 }}
            className="text-center mb-16"
          >
            <h2 className="text-3xl lg:text-4xl font-bold text-text-primary mb-4">
              Training Formats
            </h2>
            <p className="text-text-secondary max-w-xl mx-auto">
              Flexible delivery options to fit your team&apos;s schedule and location
            </p>
          </motion.div>

          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
            {trainingFormats.map((format, idx) => (
              <motion.div
                key={format.title}
                initial={{ opacity: 0, y: 20 }}
                whileInView={{ opacity: 1, y: 0 }}
                viewport={{ once: true }}
                transition={{ duration: 0.5, delay: idx * 0.1 }}
                className="glass glass-hover rounded-2xl p-6"
              >
                <div className="flex items-center justify-between mb-4">
                  <div className="w-10 h-10 rounded-lg bg-accent-cyan/10 flex items-center justify-center border border-accent-cyan/20">
                    <format.icon className="w-5 h-5 text-accent-cyan" />
                  </div>
                  <span className="text-xs text-text-muted px-2.5 py-1 rounded-md bg-bg-tertiary/60 border border-border-subtle">
                    {format.tag}
                  </span>
                </div>
                <h3 className="text-base font-semibold text-text-primary mb-2">
                  {format.title}
                </h3>
                <p className="text-sm text-text-secondary leading-relaxed">
                  {format.description}
                </p>
              </motion.div>
            ))}
          </div>
        </div>
      </section>

      {/* Metrics */}
      <section className="py-24 lg:py-32 bg-bg-secondary/30">
        <div className="max-w-7xl mx-auto px-6">
          <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
            {metrics.map((metric, idx) => (
              <motion.div
                key={metric.label}
                initial={{ opacity: 0, y: 30 }}
                whileInView={{ opacity: 1, y: 0 }}
                viewport={{ once: true }}
                transition={{ duration: 0.6, delay: idx * 0.15 }}
                className="text-center glass rounded-2xl p-10"
              >
                <AnimatedCounter target={metric.value} suffix={metric.suffix} />
                <p className="text-sm text-text-secondary mt-3 font-medium">
                  {metric.label}
                </p>
              </motion.div>
            ))}
          </div>
        </div>
      </section>

      {/* CTA — Consultation Form */}
      <section className="py-24 lg:py-32">
        <div className="max-w-7xl mx-auto px-6">
          <motion.div
            initial={{ opacity: 0, y: 30 }}
            whileInView={{ opacity: 1, y: 0 }}
            viewport={{ once: true, margin: '-100px' }}
            transition={{ duration: 0.7 }}
            className="glass rounded-2xl overflow-hidden"
          >
            <div className="grid grid-cols-1 lg:grid-cols-2">
              {/* Left — Info */}
              <div className="p-10 lg:p-14 bg-gradient-to-br from-accent-purple/10 via-transparent to-accent-cyan/5">
                <h2 className="text-2xl lg:text-3xl font-bold text-text-primary mb-4">
                  Request a Consultation
                </h2>
                <p className="text-text-secondary leading-relaxed mb-8">
                  Share your training requirements and our enterprise team will design
                  a customized program for your organization within 48 hours.
                </p>
                <ul className="space-y-4">
                  {[
                    'Needs assessment & gap analysis',
                    'Custom curriculum design',
                    'Flexible scheduling & delivery',
                    'Volume pricing for teams',
                  ].map((item) => (
                    <li key={item} className="flex items-start gap-3">
                      <span className="w-1.5 h-1.5 rounded-full bg-accent-cyan mt-2 flex-shrink-0" />
                      <span className="text-sm text-text-secondary">{item}</span>
                    </li>
                  ))}
                </ul>
              </div>

              {/* Right — Form UI */}
              <div className="p-10 lg:p-14">
                <div className="space-y-5">
                  <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                    <div>
                      <label className="block text-xs font-medium text-text-secondary mb-2">
                        Your Name
                      </label>
                      <input
                        type="text"
                        placeholder="Full name"
                        className="w-full px-4 py-3 rounded-xl bg-bg-secondary/80 border border-border-subtle text-text-primary placeholder:text-text-muted text-sm focus:outline-none focus:border-accent-cyan/40 transition-colors"
                      />
                    </div>
                    <div>
                      <label className="block text-xs font-medium text-text-secondary mb-2">
                        Company
                      </label>
                      <input
                        type="text"
                        placeholder="Company name"
                        className="w-full px-4 py-3 rounded-xl bg-bg-secondary/80 border border-border-subtle text-text-primary placeholder:text-text-muted text-sm focus:outline-none focus:border-accent-cyan/40 transition-colors"
                      />
                    </div>
                  </div>
                  <div>
                    <label className="block text-xs font-medium text-text-secondary mb-2">
                      Work Email
                    </label>
                    <input
                      type="email"
                      placeholder="you@company.com"
                      className="w-full px-4 py-3 rounded-xl bg-bg-secondary/80 border border-border-subtle text-text-primary placeholder:text-text-muted text-sm focus:outline-none focus:border-accent-cyan/40 transition-colors"
                    />
                  </div>
                  <div>
                    <label className="block text-xs font-medium text-text-secondary mb-2">
                      Team Size
                    </label>
                    <select className="w-full px-4 py-3 rounded-xl bg-bg-secondary/80 border border-border-subtle text-text-muted text-sm focus:outline-none focus:border-accent-cyan/40 transition-colors appearance-none">
                      <option>Select team size</option>
                      <option>5-10 people</option>
                      <option>10-25 people</option>
                      <option>25-50 people</option>
                      <option>50-100 people</option>
                      <option>100+ people</option>
                    </select>
                  </div>
                  <div>
                    <label className="block text-xs font-medium text-text-secondary mb-2">
                      Message
                    </label>
                    <textarea
                      placeholder="Tell us about your training needs..."
                      rows={4}
                      className="w-full px-4 py-3 rounded-xl bg-bg-secondary/80 border border-border-subtle text-text-primary placeholder:text-text-muted text-sm focus:outline-none focus:border-accent-cyan/40 transition-colors resize-none"
                    />
                  </div>
                  <button className="w-full inline-flex items-center justify-center gap-2 px-8 py-3.5 rounded-xl bg-accent-cyan text-bg-primary font-semibold text-sm hover:bg-accent-cyan/90 transition-all duration-300 hover:shadow-[0_0_30px_rgba(0,229,255,0.3)]">
                    Request Consultation
                    <ArrowRight className="w-4 h-4" />
                  </button>
                </div>
              </div>
            </div>
          </motion.div>
        </div>
      </section>
    </div>
  );
}
