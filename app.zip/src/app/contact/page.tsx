'use client';

import { useState } from 'react';
import { motion, AnimatePresence } from 'framer-motion';
import {
  Phone,
  Mail,
  MapPin,
  Clock,
  ArrowRight,
  ChevronDown,
  Send,
} from 'lucide-react';
import Link from 'next/link';

const contactInfo = [
  {
    icon: Phone,
    label: 'Phone',
    items: ['+91 99721 77745', '+91 99721 77789'],
  },
  {
    icon: Mail,
    label: 'Email',
    items: ['info@gitinfo.com', 'training@gitinfo.com'],
  },
  {
    icon: MapPin,
    label: 'Address',
    items: [
      'No 72, TSN Arcade, 28th Main Road,',
      'Jayanagar, Bengaluru, Karnataka, India',
    ],
  },
  {
    icon: Clock,
    label: 'Office Hours',
    items: ['Mon — Sat: 9:00 AM — 7:00 PM IST', 'Sun: Closed'],
  },
];

const inquiryTypes = [
  'General Inquiry',
  'Training Enrollment',
  'Corporate Training',
  'Lab Access',
  'Partnership',
  'Other',
];

const faqs = [
  {
    question: 'What certifications do you offer training for?',
    answer:
      'We offer authorized training for Cisco (CCNA, CCNP, CCIE tracks), EC-Council (CEH v12, CHFI, CPENT), CompTIA (Security+, Network+, CySA+), Microsoft Azure (AZ-900, AZ-104, AZ-500), AWS, Fortinet, Palo Alto, and more. Check our Training Programs page for the full catalog.',
  },
  {
    question: 'Do you offer online/virtual training?',
    answer:
      'Yes, we offer Live Online (Virtual Instructor-Led) training for all our courses. You get the same expert instruction, hands-on labs, and interaction as our classroom sessions — accessible from anywhere with a stable internet connection.',
  },
  {
    question: 'What is included in the course fee?',
    answer:
      'Course fees include expert instructor-led sessions, official courseware and study materials, hands-on lab access, practice exams, certification exam vouchers (for select courses), and post-training support. Contact us for specific course inclusions.',
  },
  {
    question: 'Do you provide corporate/group discounts?',
    answer:
      'Absolutely. We offer volume-based pricing for teams of 5 or more. Our corporate training team will work with you to design a customized program with flexible scheduling and delivery options. Reach out to training@gitinfo.com for a quote.',
  },
];

export default function ContactPage() {
  const [openFaq, setOpenFaq] = useState<number | null>(null);

  return (
    <div className="min-h-screen bg-bg-primary">
      {/* Hero */}
      <section className="relative py-24 lg:py-32 overflow-hidden">
        <div className="absolute inset-0 cyber-grid" />
        <div className="absolute inset-0 bg-gradient-to-b from-accent-cyan/5 via-transparent to-transparent" />
        <div className="relative max-w-7xl mx-auto px-6">
          <motion.div
            initial={{ opacity: 0, y: 30 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.7, ease: [0.16, 1, 0.3, 1] }}
            className="text-center max-w-3xl mx-auto"
          >
            <div className="inline-flex items-center gap-2 px-4 py-1.5 rounded-full border border-border-subtle bg-bg-secondary/50 backdrop-blur-sm mb-6">
              <Mail className="w-3.5 h-3.5 text-accent-cyan" />
              <span className="text-sm text-text-secondary font-medium">
                We&apos;re Here to Help
              </span>
            </div>
            <h1 className="text-4xl md:text-5xl lg:text-6xl font-bold text-text-primary mb-6 tracking-tight">
              Get in{' '}
              <span className="gradient-text-cyan">Touch</span>
            </h1>
            <p className="text-lg text-text-secondary leading-relaxed max-w-2xl mx-auto">
              Have questions about our training programs? Looking for corporate
              solutions? Our team is ready to help you chart the right path.
            </p>
          </motion.div>
        </div>
      </section>

      {/* Contact Form + Info */}
      <section className="py-24 lg:py-32">
        <div className="max-w-7xl mx-auto px-6">
          <div className="grid grid-cols-1 lg:grid-cols-5 gap-12">
            {/* Left — Form (3 cols) */}
            <motion.div
              initial={{ opacity: 0, x: -30 }}
              whileInView={{ opacity: 1, x: 0 }}
              viewport={{ once: true, margin: '-100px' }}
              transition={{ duration: 0.7 }}
              className="lg:col-span-3"
            >
              <div className="glass rounded-2xl p-8 lg:p-10">
                <h2 className="text-2xl font-bold text-text-primary mb-2">
                  Send Us a Message
                </h2>
                <p className="text-sm text-text-secondary mb-8">
                  Fill out the form and we&apos;ll get back to you within 24 hours.
                </p>

                <div className="space-y-5">
                  <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                    <div>
                      <label className="block text-xs font-medium text-text-secondary mb-2">
                        Full Name <span className="text-accent-red">*</span>
                      </label>
                      <input
                        type="text"
                        placeholder="Your name"
                        className="w-full px-4 py-3 rounded-xl bg-bg-secondary/80 border border-border-subtle text-text-primary placeholder:text-text-muted text-sm focus:outline-none focus:border-accent-cyan/40 transition-colors"
                      />
                    </div>
                    <div>
                      <label className="block text-xs font-medium text-text-secondary mb-2">
                        Email <span className="text-accent-red">*</span>
                      </label>
                      <input
                        type="email"
                        placeholder="you@email.com"
                        className="w-full px-4 py-3 rounded-xl bg-bg-secondary/80 border border-border-subtle text-text-primary placeholder:text-text-muted text-sm focus:outline-none focus:border-accent-cyan/40 transition-colors"
                      />
                    </div>
                  </div>

                  <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                    <div>
                      <label className="block text-xs font-medium text-text-secondary mb-2">
                        Phone
                      </label>
                      <input
                        type="tel"
                        placeholder="+91 XXXXX XXXXX"
                        className="w-full px-4 py-3 rounded-xl bg-bg-secondary/80 border border-border-subtle text-text-primary placeholder:text-text-muted text-sm focus:outline-none focus:border-accent-cyan/40 transition-colors"
                      />
                    </div>
                    <div>
                      <label className="block text-xs font-medium text-text-secondary mb-2">
                        Company
                      </label>
                      <input
                        type="text"
                        placeholder="Company name"
                        className="w-full px-4 py-3 rounded-xl bg-bg-secondary/80 border border-border-subtle text-text-primary placeholder:text-text-muted text-sm focus:outline-none focus:border-accent-cyan/40 transition-colors"
                      />
                    </div>
                  </div>

                  <div>
                    <label className="block text-xs font-medium text-text-secondary mb-2">
                      Inquiry Type <span className="text-accent-red">*</span>
                    </label>
                    <select className="w-full px-4 py-3 rounded-xl bg-bg-secondary/80 border border-border-subtle text-text-muted text-sm focus:outline-none focus:border-accent-cyan/40 transition-colors appearance-none">
                      <option value="">Select inquiry type</option>
                      {inquiryTypes.map((type) => (
                        <option key={type} value={type}>
                          {type}
                        </option>
                      ))}
                    </select>
                  </div>

                  <div>
                    <label className="block text-xs font-medium text-text-secondary mb-2">
                      Message <span className="text-accent-red">*</span>
                    </label>
                    <textarea
                      placeholder="Tell us about your requirements..."
                      rows={5}
                      className="w-full px-4 py-3 rounded-xl bg-bg-secondary/80 border border-border-subtle text-text-primary placeholder:text-text-muted text-sm focus:outline-none focus:border-accent-cyan/40 transition-colors resize-none"
                    />
                  </div>

                  <button className="w-full inline-flex items-center justify-center gap-2 px-8 py-3.5 rounded-xl bg-accent-cyan text-bg-primary font-semibold text-sm hover:bg-accent-cyan/90 transition-all duration-300 hover:shadow-[0_0_30px_rgba(0,229,255,0.3)]">
                    <Send className="w-4 h-4" />
                    Send Message
                  </button>
                </div>
              </div>
            </motion.div>

            {/* Right — Contact Info (2 cols) */}
            <motion.div
              initial={{ opacity: 0, x: 30 }}
              whileInView={{ opacity: 1, x: 0 }}
              viewport={{ once: true, margin: '-100px' }}
              transition={{ duration: 0.7, delay: 0.2 }}
              className="lg:col-span-2"
            >
              <div className="space-y-6">
                {contactInfo.map((info, idx) => (
                  <motion.div
                    key={info.label}
                    initial={{ opacity: 0, y: 20 }}
                    whileInView={{ opacity: 1, y: 0 }}
                    viewport={{ once: true }}
                    transition={{ duration: 0.5, delay: 0.3 + idx * 0.1 }}
                    className="glass glass-hover rounded-xl p-6"
                  >
                    <div className="flex items-start gap-4">
                      <div className="w-10 h-10 rounded-lg bg-accent-cyan/10 flex items-center justify-center border border-accent-cyan/20 flex-shrink-0">
                        <info.icon className="w-5 h-5 text-accent-cyan" />
                      </div>
                      <div>
                        <h3 className="text-sm font-semibold text-text-primary mb-2">
                          {info.label}
                        </h3>
                        {info.items.map((item) => (
                          <p key={item} className="text-sm text-text-secondary leading-relaxed">
                            {item}
                          </p>
                        ))}
                      </div>
                    </div>
                  </motion.div>
                ))}
              </div>

              {/* Quick Links */}
              <div className="mt-8 glass rounded-xl p-6">
                <h3 className="text-sm font-semibold text-text-primary mb-4">
                  Quick Links
                </h3>
                <div className="space-y-3">
                  {[
                    { label: 'View Training Programs', href: '/training' },
                    { label: 'Corporate Solutions', href: '/corporate' },
                    { label: 'Virtual Lab Access', href: '/labs' },
                  ].map((link) => (
                    <Link
                      key={link.href}
                      href={link.href}
                      className="flex items-center gap-2 text-sm text-text-secondary hover:text-accent-cyan transition-colors group"
                    >
                      <ArrowRight className="w-3.5 h-3.5 group-hover:translate-x-1 transition-transform" />
                      {link.label}
                    </Link>
                  ))}
                </div>
              </div>
            </motion.div>
          </div>
        </div>
      </section>

      {/* FAQ Section */}
      <section className="py-24 lg:py-32 bg-bg-secondary/30">
        <div className="max-w-3xl mx-auto px-6">
          <motion.div
            initial={{ opacity: 0, y: 20 }}
            whileInView={{ opacity: 1, y: 0 }}
            viewport={{ once: true, margin: '-100px' }}
            transition={{ duration: 0.6 }}
            className="text-center mb-12"
          >
            <h2 className="text-3xl lg:text-4xl font-bold text-text-primary mb-4">
              Frequently Asked Questions
            </h2>
            <p className="text-text-secondary">
              Quick answers to common questions
            </p>
          </motion.div>

          <div className="space-y-3">
            {faqs.map((faq, idx) => (
              <motion.div
                key={idx}
                initial={{ opacity: 0, y: 15 }}
                whileInView={{ opacity: 1, y: 0 }}
                viewport={{ once: true }}
                transition={{ duration: 0.4, delay: idx * 0.08 }}
              >
                <button
                  onClick={() => setOpenFaq(openFaq === idx ? null : idx)}
                  className="w-full glass glass-hover rounded-xl p-5 text-left"
                >
                  <div className="flex items-center justify-between gap-4">
                    <h3 className="text-sm font-semibold text-text-primary pr-4">
                      {faq.question}
                    </h3>
                    <ChevronDown
                      className={`w-5 h-5 text-text-muted flex-shrink-0 transition-transform duration-300 ${
                        openFaq === idx ? 'rotate-180' : ''
                      }`}
                    />
                  </div>
                  <AnimatePresence>
                    {openFaq === idx && (
                      <motion.div
                        initial={{ height: 0, opacity: 0 }}
                        animate={{ height: 'auto', opacity: 1 }}
                        exit={{ height: 0, opacity: 0 }}
                        transition={{ duration: 0.3, ease: [0.16, 1, 0.3, 1] }}
                        className="overflow-hidden"
                      >
                        <p className="text-sm text-text-secondary leading-relaxed pt-4 border-t border-border-subtle mt-4">
                          {faq.answer}
                        </p>
                      </motion.div>
                    )}
                  </AnimatePresence>
                </button>
              </motion.div>
            ))}
          </div>
        </div>
      </section>

      {/* Map / CTA */}
      <section className="py-24 lg:py-32">
        <div className="max-w-7xl mx-auto px-6">
          <motion.div
            initial={{ opacity: 0, y: 30 }}
            whileInView={{ opacity: 1, y: 0 }}
            viewport={{ once: true, margin: '-100px' }}
            transition={{ duration: 0.7 }}
            className="glass rounded-2xl p-12 lg:p-16 text-center relative overflow-hidden"
          >
            <div className="absolute inset-0 bg-gradient-to-br from-accent-cyan/5 via-transparent to-accent-purple/5" />
            <div className="relative">
              <MapPin className="w-10 h-10 text-accent-cyan mx-auto mb-6" />
              <h2 className="text-2xl lg:text-3xl font-bold text-text-primary mb-4">
                Visit Our Training Center
              </h2>
              <p className="text-text-secondary max-w-lg mx-auto mb-2">
                No 72, TSN Arcade, 28th Main Road, Jayanagar, Bengaluru, Karnataka, India
              </p>
              <p className="text-sm text-text-muted mb-8">
                Mon — Sat: 9:00 AM — 7:00 PM IST
              </p>
              <a
                href="https://maps.google.com/?q=Jayanagar+28th+Main+Road+Bengaluru"
                target="_blank"
                rel="noopener noreferrer"
                className="inline-flex items-center gap-2 px-8 py-3.5 rounded-xl bg-accent-cyan text-bg-primary font-semibold text-sm hover:bg-accent-cyan/90 transition-all duration-300 hover:shadow-[0_0_30px_rgba(0,229,255,0.3)]"
              >
                Get Directions
                <ArrowRight className="w-4 h-4" />
              </a>
            </div>
          </motion.div>
        </div>
      </section>
    </div>
  );
}
