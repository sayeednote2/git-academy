'use client';

import { useState, useEffect } from 'react';
import { motion } from 'framer-motion';
import {
  Shield,
  Skull,
  Cloud,
  Eye,
  Clock,
  Server,
  BookOpen,
  FileCheck,
  Wifi,
  Zap,
  ArrowRight,
  Terminal,
  ChevronRight,
} from 'lucide-react';
import Link from 'next/link';

const labCategories = [
  {
    title: 'Network Security',
    icon: Shield,
    description:
      'Configure firewalls, VPNs, and intrusion detection systems on real Cisco, Fortinet, and Palo Alto equipment.',
    color: 'text-accent-cyan',
    borderColor: 'border-accent-cyan/30',
    bgGlow: 'from-accent-cyan/10',
  },
  {
    title: 'Ethical Hacking',
    icon: Skull,
    description:
      'Practice 340+ attack techniques in sandboxed environments. Exploit vulnerabilities, pivot networks, and extract flags.',
    color: 'text-accent-red',
    borderColor: 'border-accent-red/30',
    bgGlow: 'from-accent-red/10',
  },
  {
    title: 'Cloud Defense',
    icon: Cloud,
    description:
      'Secure AWS and Azure cloud workloads. Practice IAM policy hardening, network segmentation, and incident response.',
    color: 'text-accent-amber',
    borderColor: 'border-accent-amber/30',
    bgGlow: 'from-accent-amber/10',
  },
  {
    title: 'SOC Operations',
    icon: Eye,
    description:
      'Operate a full Security Operations Center. Triage alerts, analyze logs with SIEM tools, and respond to live incidents.',
    color: 'text-accent-purple',
    borderColor: 'border-accent-purple/30',
    bgGlow: 'from-accent-purple/10',
  },
];

const features = [
  {
    icon: Clock,
    title: '24/7 Access',
    description: 'Labs available around the clock. Practice anytime, anywhere.',
  },
  {
    icon: Server,
    title: 'Real Hardware',
    description: 'Cisco routers, Fortinet firewalls, and enterprise-grade switches.',
  },
  {
    icon: BookOpen,
    title: 'Guided Scenarios',
    description: 'Step-by-step lab guides with objectives and validation checks.',
  },
  {
    icon: FileCheck,
    title: 'Practice Exams',
    description: 'Simulate real certification exams with timed test environments.',
  },
  {
    icon: Wifi,
    title: 'Remote VPN Access',
    description: 'Secure VPN tunnels to access lab equipment from any location.',
  },
  {
    icon: Zap,
    title: 'Enterprise Grade',
    description: 'Production-level topologies mirroring real corporate networks.',
  },
];

const terminalLines = [
  { prompt: true, text: 'ssh student@lab-gateway.gitacademy.com' },
  { prompt: false, text: 'Connected to GIT Academy Lab Environment v4.2' },
  { prompt: false, text: 'Authenticating... ✓' },
  { prompt: false, text: '' },
  { prompt: false, text: '╔══════════════════════════════════════════╗' },
  { prompt: false, text: '║  Welcome to CEH v12 — Lab Module 07     ║' },
  { prompt: false, text: '║  Target: 10.10.14.0/24 Network           ║' },
  { prompt: false, text: '║  Objective: Enumerate & Exploit          ║' },
  { prompt: false, text: '╚══════════════════════════════════════════╝' },
  { prompt: false, text: '' },
  { prompt: true, text: 'nmap -sV -sC 10.10.14.128' },
  { prompt: false, text: 'Starting Nmap 7.94 — https://nmap.org' },
  { prompt: false, text: 'PORT     STATE SERVICE  VERSION' },
  { prompt: false, text: '22/tcp   open  ssh      OpenSSH 8.9p1' },
  { prompt: false, text: '80/tcp   open  http     Apache 2.4.54' },
  { prompt: false, text: '443/tcp  open  ssl/http nginx 1.22' },
  { prompt: false, text: '3306/tcp open  mysql    MySQL 8.0.31' },
  { prompt: false, text: '' },
  { prompt: true, text: 'gobuster dir -u http://10.10.14.128 -w common.txt' },
  { prompt: false, text: '/admin         (Status: 302) [Size: 0]' },
  { prompt: false, text: '/api           (Status: 200) [Size: 1247]' },
  { prompt: false, text: '/uploads       (Status: 403) [Size: 277]' },
];

function TerminalMockup() {
  const [visibleLines, setVisibleLines] = useState(0);

  useEffect(() => {
    const timer = setInterval(() => {
      setVisibleLines((prev) => {
        if (prev >= terminalLines.length) return prev;
        return prev + 1;
      });
    }, 200);
    return () => clearInterval(timer);
  }, []);

  return (
    <div className="glass rounded-2xl overflow-hidden border border-border-subtle">
      {/* Title bar */}
      <div className="flex items-center gap-2 px-4 py-3 bg-bg-tertiary/80 border-b border-border-subtle">
        <div className="flex gap-1.5">
          <div className="w-3 h-3 rounded-full bg-accent-red/70" />
          <div className="w-3 h-3 rounded-full bg-accent-amber/70" />
          <div className="w-3 h-3 rounded-full bg-accent-green/70" />
        </div>
        <div className="flex items-center gap-2 ml-3">
          <Terminal className="w-3.5 h-3.5 text-text-muted" />
          <span className="text-xs font-mono text-text-muted">
            student@lab-gateway — bash
          </span>
        </div>
      </div>

      {/* Terminal content */}
      <div className="p-5 font-mono text-sm leading-relaxed h-[400px] overflow-hidden bg-[#0d1117]">
        {terminalLines.slice(0, visibleLines).map((line, i) => (
          <div key={i} className="flex items-start">
            {line.prompt && (
              <span className="text-accent-green mr-2 flex-shrink-0">
                ┌──(student㉿lab)
                <br />
                └─$ {' '}
              </span>
            )}
            <span
              className={
                line.prompt
                  ? 'text-text-primary'
                  : line.text.includes('✓')
                    ? 'text-accent-green'
                    : line.text.includes('║') || line.text.includes('╔') || line.text.includes('╚')
                      ? 'text-accent-cyan/70'
                      : line.text.includes('open')
                        ? 'text-accent-amber'
                        : line.text.includes('Status:')
                          ? 'text-accent-purple'
                          : 'text-text-secondary'
              }
            >
              {line.text}
            </span>
          </div>
        ))}
        {visibleLines < terminalLines.length && (
          <span className="inline-block w-2 h-4 bg-accent-cyan/70 animate-pulse ml-1" />
        )}
      </div>
    </div>
  );
}

export default function LabsPage() {
  return (
    <div className="min-h-screen bg-bg-primary">
      {/* Hero */}
      <section className="relative py-24 lg:py-32 overflow-hidden">
        <div className="absolute inset-0 cyber-grid-dense" />
        <div className="absolute inset-0 bg-gradient-to-b from-accent-green/5 via-transparent to-transparent" />
        {/* Scan line effect */}
        <div className="absolute inset-0 overflow-hidden pointer-events-none">
          <div className="absolute w-full h-px bg-accent-cyan/10 animate-[scan-line_3s_linear_infinite]" />
        </div>
        <div className="relative max-w-7xl mx-auto px-6">
          <motion.div
            initial={{ opacity: 0, y: 30 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.7, ease: [0.16, 1, 0.3, 1] }}
            className="text-center max-w-3xl mx-auto"
          >
            <div className="inline-flex items-center gap-2 px-4 py-1.5 rounded-full border border-accent-green/30 bg-accent-green/10 backdrop-blur-sm mb-6">
              <Terminal className="w-3.5 h-3.5 text-accent-green" />
              <span className="text-sm text-accent-green font-medium font-mono">
                Hands-on Lab Environment
              </span>
            </div>
            <h1 className="text-4xl md:text-5xl lg:text-6xl font-bold text-text-primary mb-6 tracking-tight">
              Virtual{' '}
              <span className="gradient-text-cyan">Labs</span>
            </h1>
            <p className="text-lg text-text-secondary leading-relaxed max-w-2xl mx-auto mb-10">
              Access enterprise-grade lab environments from anywhere. Practice on real
              hardware, run attack simulations, and validate your skills in sandboxed
              networks designed by industry experts.
            </p>
            <div className="flex flex-col sm:flex-row items-center justify-center gap-4">
              <Link
                href="/contact"
                className="inline-flex items-center gap-2 px-8 py-3.5 rounded-xl bg-accent-cyan text-bg-primary font-semibold text-sm hover:bg-accent-cyan/90 transition-all duration-300 hover:shadow-[0_0_30px_rgba(0,229,255,0.3)]"
              >
                Request Lab Access
                <ArrowRight className="w-4 h-4" />
              </Link>
              <Link
                href="/training"
                className="inline-flex items-center gap-2 px-8 py-3.5 rounded-xl border border-border-subtle text-text-primary font-medium text-sm hover:border-accent-cyan/30 transition-all duration-300"
              >
                View Courses
                <ChevronRight className="w-4 h-4" />
              </Link>
            </div>
          </motion.div>
        </div>
      </section>

      {/* Lab Categories */}
      <section className="py-24 lg:py-32">
        <div className="max-w-7xl mx-auto px-6">
          <motion.div
            initial={{ opacity: 0, y: 20 }}
            whileInView={{ opacity: 1, y: 0 }}
            viewport={{ once: true, margin: '-100px' }}
            transition={{ duration: 0.6 }}
            className="text-center mb-16"
          >
            <h2 className="text-3xl lg:text-4xl font-bold text-text-primary mb-4">
              Lab Categories
            </h2>
            <p className="text-text-secondary max-w-xl mx-auto">
              Specialized environments for every domain of cybersecurity
            </p>
          </motion.div>

          <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
            {labCategories.map((lab, idx) => (
              <motion.div
                key={lab.title}
                initial={{ opacity: 0, y: 30 }}
                whileInView={{ opacity: 1, y: 0 }}
                viewport={{ once: true, margin: '-50px' }}
                transition={{ duration: 0.6, delay: idx * 0.1 }}
                className={`group glass glass-hover rounded-2xl p-8 border-l-2 ${lab.borderColor}`}
              >
                <div
                  className={`w-12 h-12 rounded-xl flex items-center justify-center mb-5 bg-gradient-to-br ${lab.bgGlow} to-transparent border border-border-subtle`}
                >
                  <lab.icon className={`w-6 h-6 ${lab.color}`} />
                </div>
                <h3 className="text-xl font-bold text-text-primary mb-3 group-hover:text-accent-cyan transition-colors duration-300">
                  {lab.title}
                </h3>
                <p className="text-sm text-text-secondary leading-relaxed">
                  {lab.description}
                </p>
              </motion.div>
            ))}
          </div>
        </div>
      </section>

      {/* Features Grid */}
      <section className="py-24 lg:py-32 bg-bg-secondary/30">
        <div className="max-w-7xl mx-auto px-6">
          <motion.div
            initial={{ opacity: 0, y: 20 }}
            whileInView={{ opacity: 1, y: 0 }}
            viewport={{ once: true, margin: '-100px' }}
            transition={{ duration: 0.6 }}
            className="text-center mb-16"
          >
            <h2 className="text-3xl lg:text-4xl font-bold text-text-primary mb-4">
              Lab Infrastructure
            </h2>
            <p className="text-text-secondary max-w-xl mx-auto">
              Enterprise-grade lab facilities built for serious professionals
            </p>
          </motion.div>

          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
            {features.map((feature, idx) => (
              <motion.div
                key={feature.title}
                initial={{ opacity: 0, y: 20 }}
                whileInView={{ opacity: 1, y: 0 }}
                viewport={{ once: true }}
                transition={{ duration: 0.5, delay: idx * 0.08 }}
                className="glass glass-hover rounded-2xl p-6"
              >
                <div className="w-10 h-10 rounded-lg bg-accent-cyan/10 flex items-center justify-center mb-4 border border-accent-cyan/20">
                  <feature.icon className="w-5 h-5 text-accent-cyan" />
                </div>
                <h3 className="text-base font-semibold text-text-primary mb-2">
                  {feature.title}
                </h3>
                <p className="text-sm text-text-secondary leading-relaxed">
                  {feature.description}
                </p>
              </motion.div>
            ))}
          </div>
        </div>
      </section>

      {/* Terminal Demo */}
      <section className="py-24 lg:py-32">
        <div className="max-w-7xl mx-auto px-6">
          <div className="grid grid-cols-1 lg:grid-cols-2 gap-12 items-center">
            <motion.div
              initial={{ opacity: 0, x: -30 }}
              whileInView={{ opacity: 1, x: 0 }}
              viewport={{ once: true, margin: '-100px' }}
              transition={{ duration: 0.7 }}
            >
              <h2 className="text-3xl lg:text-4xl font-bold text-text-primary mb-6">
                Real-World Attack{' '}
                <span className="gradient-text-cyan">Simulations</span>
              </h2>
              <p className="text-text-secondary leading-relaxed mb-6">
                Our labs replicate enterprise network topologies with vulnerable
                machines, misconfigured services, and hidden attack vectors. Students
                practice reconnaissance, exploitation, and post-exploitation in fully
                sandboxed environments.
              </p>
              <ul className="space-y-3 mb-8">
                {[
                  'Full network topology with multiple subnets',
                  'Pre-configured vulnerable machines and services',
                  'Real-time scoring and flag submission',
                  'Detailed solution walkthroughs after completion',
                ].map((item) => (
                  <li key={item} className="flex items-start gap-3">
                    <span className="w-1.5 h-1.5 rounded-full bg-accent-cyan mt-2 flex-shrink-0" />
                    <span className="text-sm text-text-secondary">{item}</span>
                  </li>
                ))}
              </ul>
              <Link
                href="/contact"
                className="inline-flex items-center gap-2 text-sm font-medium text-accent-cyan hover:text-white transition-colors"
              >
                Request Lab Access
                <ArrowRight className="w-4 h-4" />
              </Link>
            </motion.div>

            <motion.div
              initial={{ opacity: 0, x: 30 }}
              whileInView={{ opacity: 1, x: 0 }}
              viewport={{ once: true, margin: '-100px' }}
              transition={{ duration: 0.7, delay: 0.2 }}
            >
              <TerminalMockup />
            </motion.div>
          </div>
        </div>
      </section>

      {/* CTA */}
      <section className="py-24 lg:py-32">
        <div className="max-w-7xl mx-auto px-6">
          <motion.div
            initial={{ opacity: 0, y: 30 }}
            whileInView={{ opacity: 1, y: 0 }}
            viewport={{ once: true, margin: '-100px' }}
            transition={{ duration: 0.7 }}
            className="glass rounded-2xl p-12 lg:p-16 text-center relative overflow-hidden"
          >
            <div className="absolute inset-0 cyber-grid" />
            <div className="absolute inset-0 bg-gradient-to-br from-accent-green/5 via-transparent to-accent-cyan/5" />
            <div className="relative">
              <h2 className="text-2xl lg:text-3xl font-bold text-text-primary mb-4">
                Get Hands-On Experience Today
              </h2>
              <p className="text-text-secondary max-w-xl mx-auto mb-8">
                Access enterprise-grade lab environments bundled with your training
                program. Available for individuals and corporate teams.
              </p>
              <Link
                href="/contact"
                className="inline-flex items-center gap-2 px-8 py-3.5 rounded-xl bg-accent-cyan text-bg-primary font-semibold text-sm hover:bg-accent-cyan/90 transition-all duration-300 hover:shadow-[0_0_30px_rgba(0,229,255,0.3)]"
              >
                Request Lab Access
                <ArrowRight className="w-4 h-4" />
              </Link>
            </div>
          </motion.div>
        </div>
      </section>
    </div>
  );
}
