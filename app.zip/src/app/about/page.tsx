'use client';

import { motion } from 'framer-motion';
import {
  Award,
  Lightbulb,
  ShieldCheck,
  Rocket,
  Building2,
  ArrowRight,
  Users,
} from 'lucide-react';
import { partnerLogos } from '@/lib/data';
import Link from 'next/link';

const values = [
  {
    icon: Award,
    title: 'Excellence',
    description:
      'We hold ourselves to the highest standards in training delivery, curriculum design, and student outcomes.',
    color: 'text-accent-cyan',
    borderColor: 'border-accent-cyan/30',
  },
  {
    icon: Lightbulb,
    title: 'Innovation',
    description:
      'Continuously evolving our programs with cutting-edge lab technologies, AI-driven tools, and real-world attack simulations.',
    color: 'text-accent-amber',
    borderColor: 'border-accent-amber/30',
  },
  {
    icon: ShieldCheck,
    title: 'Integrity',
    description:
      'Transparent pricing, honest guidance, and genuine commitment to every student\'s career growth.',
    color: 'text-accent-green',
    borderColor: 'border-accent-green/30',
  },
  {
    icon: Rocket,
    title: 'Impact',
    description:
      'Measuring success by the careers transformed, teams upskilled, and organizations secured through our training.',
    color: 'text-accent-purple',
    borderColor: 'border-accent-purple/30',
  },
];

const milestones = [
  {
    year: '2002',
    title: 'Founded in Bangalore',
    description: 'GIT Academy established as a premier IT training center in Jayanagar, Bengaluru.',
  },
  {
    year: '2005',
    title: 'Cisco Learning Partner',
    description: 'Became an authorized Cisco training partner, offering CCNA and CCNP programs.',
  },
  {
    year: '2010',
    title: 'EC-Council Partnership',
    description: 'Added CEH, CHFI, and ethical hacking certifications to our training catalog.',
  },
  {
    year: '2015',
    title: '5,000 Professionals Trained',
    description: 'Reached the milestone of training 5,000+ cybersecurity professionals.',
  },
  {
    year: '2020',
    title: 'Virtual Lab Infrastructure',
    description: 'Launched enterprise-grade virtual labs with 24/7 remote access capabilities.',
  },
  {
    year: '2024',
    title: '10,000+ Trained',
    description: 'Surpassed 10,000 professionals trained across 200+ certification programs.',
  },
];

const leadershipTeam = [
  {
    name: 'Training Director',
    role: 'Head of Training Operations',
    description: 'Oversees all training programs and curriculum development.',
  },
  {
    name: 'Technical Lead',
    role: 'Senior Lab Architect',
    description: 'Designs and maintains our virtual lab infrastructure.',
  },
  {
    name: 'Program Manager',
    role: 'Corporate Training Lead',
    description: 'Manages enterprise training partnerships and custom programs.',
  },
];

export default function AboutPage() {
  return (
    <div className="min-h-screen bg-bg-primary">
      {/* Hero */}
      <section className="relative py-24 lg:py-32 overflow-hidden">
        <div className="absolute inset-0 cyber-grid" />
        <div className="absolute inset-0 bg-gradient-to-b from-accent-cyan/5 via-transparent to-transparent" />
        <div className="relative max-w-7xl mx-auto px-6">
          <motion.div
            initial={{ opacity: 0, y: 30 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.7, ease: [0.16, 1, 0.3, 1] }}
            className="text-center max-w-3xl mx-auto"
          >
            <div className="inline-flex items-center gap-2 px-4 py-1.5 rounded-full border border-border-subtle bg-bg-secondary/50 backdrop-blur-sm mb-6">
              <Building2 className="w-3.5 h-3.5 text-accent-cyan" />
              <span className="text-sm text-text-secondary font-medium">
                Since 2002
              </span>
            </div>
            <h1 className="text-4xl md:text-5xl lg:text-6xl font-bold text-text-primary mb-6 tracking-tight">
              Our{' '}
              <span className="gradient-text-cyan">Story</span>
            </h1>
            <p className="text-lg text-text-secondary leading-relaxed max-w-2xl mx-auto">
              For over two decades, GIT Academy has been Bangalore&apos;s trusted name
              in cybersecurity and IT training — shaping the professionals who defend
              the digital world.
            </p>
          </motion.div>
        </div>
      </section>

      {/* Story Section */}
      <section className="py-24 lg:py-32">
        <div className="max-w-7xl mx-auto px-6">
          <div className="grid grid-cols-1 lg:grid-cols-2 gap-16 items-center">
            <motion.div
              initial={{ opacity: 0, x: -30 }}
              whileInView={{ opacity: 1, x: 0 }}
              viewport={{ once: true, margin: '-100px' }}
              transition={{ duration: 0.7 }}
            >
              <h2 className="text-3xl lg:text-4xl font-bold text-text-primary mb-6">
                Two Decades of{' '}
                <span className="gradient-text">Excellence</span>
              </h2>
              <div className="space-y-5 text-text-secondary leading-relaxed">
                <p>
                  Founded in 2002 in Bangalore, India, GIT Academy began with a
                  singular mission: to bridge the gap between academic education and
                  industry-ready cybersecurity skills.
                </p>
                <p>
                  Over 20+ years, we&apos;ve grown from a Cisco-focused training
                  center into a comprehensive cybersecurity academy — partnering with
                  EC-Council, CompTIA, Microsoft, AWS, Fortinet, Palo Alto, and Red
                  Hat to deliver the most current, hands-on certification programs
                  available.
                </p>
                <p>
                  Our mission remains clear: to create the next generation of
                  cybersecurity professionals who can defend critical infrastructure,
                  protect digital assets, and drive security innovation across
                  industries.
                </p>
              </div>
            </motion.div>

            <motion.div
              initial={{ opacity: 0, x: 30 }}
              whileInView={{ opacity: 1, x: 0 }}
              viewport={{ once: true, margin: '-100px' }}
              transition={{ duration: 0.7, delay: 0.2 }}
              className="glass rounded-2xl p-10 relative overflow-hidden"
            >
              <div className="absolute inset-0 bg-gradient-to-br from-accent-cyan/5 via-transparent to-accent-purple/5" />
              <div className="relative space-y-8">
                {[
                  { value: '20+', label: 'Years of Excellence' },
                  { value: '10,000+', label: 'Professionals Trained' },
                  { value: '200+', label: 'Training Programs' },
                  { value: '95%', label: 'Certification Pass Rate' },
                ].map((stat, idx) => (
                  <div key={stat.label} className="flex items-center gap-6">
                    <span className="text-3xl font-bold text-accent-cyan font-mono w-24 flex-shrink-0">
                      {stat.value}
                    </span>
                    <div>
                      <div className="h-px w-full bg-border-subtle mb-2" />
                      <span className="text-sm text-text-secondary">{stat.label}</span>
                    </div>
                  </div>
                ))}
              </div>
            </motion.div>
          </div>
        </div>
      </section>

      {/* Values */}
      <section className="py-24 lg:py-32 bg-bg-secondary/30">
        <div className="max-w-7xl mx-auto px-6">
          <motion.div
            initial={{ opacity: 0, y: 20 }}
            whileInView={{ opacity: 1, y: 0 }}
            viewport={{ once: true, margin: '-100px' }}
            transition={{ duration: 0.6 }}
            className="text-center mb-16"
          >
            <h2 className="text-3xl lg:text-4xl font-bold text-text-primary mb-4">
              Our Values
            </h2>
            <p className="text-text-secondary max-w-xl mx-auto">
              The principles that guide everything we do
            </p>
          </motion.div>

          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
            {values.map((value, idx) => (
              <motion.div
                key={value.title}
                initial={{ opacity: 0, y: 30 }}
                whileInView={{ opacity: 1, y: 0 }}
                viewport={{ once: true }}
                transition={{ duration: 0.5, delay: idx * 0.1 }}
                className={`glass glass-hover rounded-2xl p-7 border-t-2 ${value.borderColor}`}
              >
                <div className="w-12 h-12 rounded-xl bg-bg-tertiary border border-border-subtle flex items-center justify-center mb-5">
                  <value.icon className={`w-6 h-6 ${value.color}`} />
                </div>
                <h3 className="text-lg font-bold text-text-primary mb-2">
                  {value.title}
                </h3>
                <p className="text-sm text-text-secondary leading-relaxed">
                  {value.description}
                </p>
              </motion.div>
            ))}
          </div>
        </div>
      </section>

      {/* Timeline */}
      <section className="py-24 lg:py-32">
        <div className="max-w-7xl mx-auto px-6">
          <motion.div
            initial={{ opacity: 0, y: 20 }}
            whileInView={{ opacity: 1, y: 0 }}
            viewport={{ once: true, margin: '-100px' }}
            transition={{ duration: 0.6 }}
            className="text-center mb-16"
          >
            <h2 className="text-3xl lg:text-4xl font-bold text-text-primary mb-4">
              Our Journey
            </h2>
            <p className="text-text-secondary max-w-xl mx-auto">
              Key milestones in GIT Academy&apos;s growth
            </p>
          </motion.div>

          <div className="relative">
            {/* Vertical line — desktop */}
            <div className="hidden lg:block absolute left-1/2 top-0 bottom-0 w-px bg-gradient-to-b from-accent-cyan/20 via-accent-purple/20 to-accent-cyan/20" />

            <div className="space-y-12 lg:space-y-0">
              {milestones.map((milestone, idx) => (
                <motion.div
                  key={milestone.year}
                  initial={{ opacity: 0, y: 30 }}
                  whileInView={{ opacity: 1, y: 0 }}
                  viewport={{ once: true, margin: '-50px' }}
                  transition={{ duration: 0.6, delay: idx * 0.1 }}
                  className={`relative lg:flex lg:items-center lg:py-8 ${
                    idx % 2 === 0 ? 'lg:flex-row' : 'lg:flex-row-reverse'
                  }`}
                >
                  {/* Content */}
                  <div className={`lg:w-1/2 ${idx % 2 === 0 ? 'lg:pr-16 lg:text-right' : 'lg:pl-16'}`}>
                    <div className="glass glass-hover rounded-xl p-6">
                      <span className="text-2xl font-bold text-accent-cyan font-mono">
                        {milestone.year}
                      </span>
                      <h3 className="text-lg font-bold text-text-primary mt-2 mb-2">
                        {milestone.title}
                      </h3>
                      <p className="text-sm text-text-secondary leading-relaxed">
                        {milestone.description}
                      </p>
                    </div>
                  </div>

                  {/* Center dot */}
                  <div className="hidden lg:flex absolute left-1/2 -translate-x-1/2 w-4 h-4 rounded-full bg-bg-primary border-2 border-accent-cyan items-center justify-center z-10">
                    <div className="w-2 h-2 rounded-full bg-accent-cyan" />
                  </div>

                  {/* Empty half */}
                  <div className="hidden lg:block lg:w-1/2" />
                </motion.div>
              ))}
            </div>
          </div>
        </div>
      </section>

      {/* Authorized Partners */}
      <section className="py-24 lg:py-32 bg-bg-secondary/30">
        <div className="max-w-7xl mx-auto px-6">
          <motion.div
            initial={{ opacity: 0, y: 20 }}
            whileInView={{ opacity: 1, y: 0 }}
            viewport={{ once: true, margin: '-100px' }}
            transition={{ duration: 0.6 }}
            className="text-center mb-16"
          >
            <h2 className="text-3xl lg:text-4xl font-bold text-text-primary mb-4">
              Authorized Training Partners
            </h2>
            <p className="text-text-secondary max-w-xl mx-auto">
              We hold official partnerships with the world&apos;s leading technology vendors
            </p>
          </motion.div>

          <div className="grid grid-cols-2 md:grid-cols-3 lg:grid-cols-4 xl:grid-cols-6 gap-4">
            {partnerLogos.map((partner, idx) => (
              <motion.div
                key={partner}
                initial={{ opacity: 0, scale: 0.9 }}
                whileInView={{ opacity: 1, scale: 1 }}
                viewport={{ once: true }}
                transition={{ duration: 0.4, delay: idx * 0.05 }}
                className="glass glass-hover rounded-xl p-5 flex items-center justify-center"
              >
                <span className="text-sm font-semibold text-text-secondary text-center">
                  {partner}
                </span>
              </motion.div>
            ))}
          </div>
        </div>
      </section>

      {/* Team */}
      <section className="py-24 lg:py-32">
        <div className="max-w-7xl mx-auto px-6">
          <motion.div
            initial={{ opacity: 0, y: 20 }}
            whileInView={{ opacity: 1, y: 0 }}
            viewport={{ once: true, margin: '-100px' }}
            transition={{ duration: 0.6 }}
            className="text-center mb-16"
          >
            <h2 className="text-3xl lg:text-4xl font-bold text-text-primary mb-4">
              Leadership
            </h2>
            <p className="text-text-secondary max-w-xl mx-auto">
              Meet the team driving GIT Academy&apos;s mission forward
            </p>
          </motion.div>

          <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
            {leadershipTeam.map((member, idx) => (
              <motion.div
                key={member.name}
                initial={{ opacity: 0, y: 30 }}
                whileInView={{ opacity: 1, y: 0 }}
                viewport={{ once: true }}
                transition={{ duration: 0.5, delay: idx * 0.1 }}
                className="glass glass-hover rounded-2xl p-8 text-center"
              >
                {/* Avatar placeholder */}
                <div className="w-20 h-20 rounded-2xl bg-bg-tertiary border border-border-subtle flex items-center justify-center mx-auto mb-5">
                  <Users className="w-8 h-8 text-text-muted" />
                </div>
                <h3 className="text-lg font-bold text-text-primary mb-1">
                  {member.name}
                </h3>
                <p className="text-sm text-accent-cyan mb-3">{member.role}</p>
                <p className="text-sm text-text-secondary leading-relaxed">
                  {member.description}
                </p>
              </motion.div>
            ))}
          </div>
        </div>
      </section>

      {/* CTA */}
      <section className="py-24 lg:py-32">
        <div className="max-w-7xl mx-auto px-6">
          <motion.div
            initial={{ opacity: 0, y: 30 }}
            whileInView={{ opacity: 1, y: 0 }}
            viewport={{ once: true, margin: '-100px' }}
            transition={{ duration: 0.7 }}
            className="glass rounded-2xl p-12 lg:p-16 text-center relative overflow-hidden"
          >
            <div className="absolute inset-0 bg-gradient-to-br from-accent-cyan/5 via-transparent to-accent-purple/5" />
            <div className="relative">
              <h2 className="text-2xl lg:text-3xl font-bold text-text-primary mb-4">
                Join Our Next Cohort
              </h2>
              <p className="text-text-secondary max-w-xl mx-auto mb-8">
                Become part of a community of 10,000+ cybersecurity professionals who
                trusted GIT Academy to launch their careers.
              </p>
              <div className="flex flex-col sm:flex-row items-center justify-center gap-4">
                <Link
                  href="/training"
                  className="inline-flex items-center gap-2 px-8 py-3.5 rounded-xl bg-accent-cyan text-bg-primary font-semibold text-sm hover:bg-accent-cyan/90 transition-all duration-300 hover:shadow-[0_0_30px_rgba(0,229,255,0.3)]"
                >
                  Explore Programs
                  <ArrowRight className="w-4 h-4" />
                </Link>
                <Link
                  href="/contact"
                  className="inline-flex items-center gap-2 px-8 py-3.5 rounded-xl border border-border-subtle text-text-primary font-medium text-sm hover:border-accent-cyan/30 transition-all duration-300"
                >
                  Contact Us
                </Link>
              </div>
            </div>
          </motion.div>
        </div>
      </section>
    </div>
  );
}
