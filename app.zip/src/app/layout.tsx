import type { Metadata } from "next";
import { Inter, JetBrains_Mono } from "next/font/google";
import "./globals.css";
import { Navbar } from "@/components/layout/Navbar";
import { Footer } from "@/components/layout/Footer";

const inter = Inter({
  variable: "--font-inter",
  subsets: ["latin"],
  display: "swap",
});

const jetbrainsMono = JetBrains_Mono({
  variable: "--font-jetbrains",
  subsets: ["latin"],
  display: "swap",
});

export const metadata: Metadata = {
  title: {
    default: "GIT Academy — Premier Cybersecurity Training & Certifications",
    template: "%s | GIT Academy",
  },
  description:
    "Master cybersecurity with world-class training from GIT Academy. Industry certifications from Cisco, EC-Council, CompTIA, Microsoft, and more. Hands-on labs. Expert instructors. Since 2002.",
  keywords: [
    "cybersecurity training",
    "CCNA certification",
    "CEH training",
    "CompTIA Security+",
    "network security courses",
    "ethical hacking course",
    "cybersecurity certifications",
    "IT training Bangalore",
    "Cisco training",
    "GIT Academy",
  ],
  authors: [{ name: "GIT Academy" }],
  creator: "GIT Academy",
  openGraph: {
    type: "website",
    locale: "en_US",
    url: "https://gitinfo.com",
    siteName: "GIT Academy",
    title: "GIT Academy — Premier Cybersecurity Training & Certifications",
    description:
      "Master cybersecurity with world-class training. Industry certifications, hands-on labs, expert instructors.",
  },
  twitter: {
    card: "summary_large_image",
    title: "GIT Academy — Premier Cybersecurity Training & Certifications",
    description:
      "Master cybersecurity with world-class training. Industry certifications, hands-on labs, expert instructors.",
  },
  robots: {
    index: true,
    follow: true,
    googleBot: {
      index: true,
      follow: true,
      "max-video-preview": -1,
      "max-image-preview": "large",
      "max-snippet": -1,
    },
  },
};

export default function RootLayout({
  children,
}: Readonly<{
  children: React.ReactNode;
}>) {
  return (
    <html
      lang="en"
      className={`${inter.variable} ${jetbrainsMono.variable}`}
    >
      <body className="min-h-screen flex flex-col font-[family-name:var(--font-inter)] antialiased">
        <Navbar />
        <main className="flex-1">{children}</main>
        <Footer />
      </body>
    </html>
  );
}
