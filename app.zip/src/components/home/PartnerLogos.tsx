'use client';

import { partnerLogos } from '@/lib/data';

function MarqueeRow({
  items,
  reverse = false,
}: {
  items: string[];
  reverse?: boolean;
}) {
  const doubled = [...items, ...items];

  return (
    <div className="relative flex overflow-hidden group">
      <div
        className={`flex shrink-0 gap-0 ${
          reverse ? 'animate-marquee direction-reverse' : 'animate-marquee'
        }`}
        style={{
          animationDirection: reverse ? 'reverse' : 'normal',
        }}
      >
        {doubled.map((name, i) => (
          <span
            key={`${name}-${i}`}
            className="flex items-center shrink-0 px-8 text-xl font-semibold text-white/[0.07] hover:text-white/25 transition-colors duration-500 select-none"
          >
            {name}
            <span className="ml-8 text-white/[0.05]">◆</span>
          </span>
        ))}
      </div>
      <div
        className={`flex shrink-0 gap-0 ${
          reverse ? 'animate-marquee direction-reverse' : 'animate-marquee'
        }`}
        style={{
          animationDirection: reverse ? 'reverse' : 'normal',
        }}
      >
        {doubled.map((name, i) => (
          <span
            key={`${name}-dup-${i}`}
            className="flex items-center shrink-0 px-8 text-xl font-semibold text-white/[0.07] hover:text-white/25 transition-colors duration-500 select-none"
          >
            {name}
            <span className="ml-8 text-white/[0.05]">◆</span>
          </span>
        ))}
      </div>
    </div>
  );
}

export function PartnerLogos() {
  const firstHalf = partnerLogos.slice(0, Math.ceil(partnerLogos.length / 2));
  const secondHalf = partnerLogos.slice(Math.ceil(partnerLogos.length / 2));

  return (
    <section className="relative py-14 bg-bg-secondary/50 border-y border-border-subtle overflow-hidden">
      <div className="space-y-6">
        <MarqueeRow items={[...firstHalf, ...secondHalf]} />
        <MarqueeRow items={[...secondHalf, ...firstHalf]} reverse />
      </div>
    </section>
  );
}
