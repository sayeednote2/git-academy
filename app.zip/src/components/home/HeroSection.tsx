'use client';

import { motion } from 'framer-motion';
import { ChevronDown } from 'lucide-react';
import Link from 'next/link';

const containerVariants = {
  hidden: {},
  visible: {
    transition: {
      staggerChildren: 0.15,
      delayChildren: 0.3,
    },
  },
};

const fadeUp = {
  hidden: { opacity: 0, y: 30 },
  visible: {
    opacity: 1,
    y: 0,
    transition: { duration: 0.7, ease: [0.16, 1, 0.3, 1] as const },
  },
};

export function HeroSection() {
  return (
    <section className="relative min-h-screen flex items-center justify-center overflow-hidden">
      {/* ── Cyber-grid background ─────────────────────────── */}
      <div className="absolute inset-0 cyber-grid" />

      {/* ── Radial gradient overlays ──────────────────────── */}
      <div
        className="absolute top-0 left-0 w-[800px] h-[800px] -translate-x-1/3 -translate-y-1/3 rounded-full pointer-events-none"
        style={{
          background:
            'radial-gradient(circle, rgba(0,229,255,0.10) 0%, transparent 70%)',
        }}
      />
      <div
        className="absolute bottom-0 right-0 w-[700px] h-[700px] translate-x-1/4 translate-y-1/4 rounded-full pointer-events-none"
        style={{
          background:
            'radial-gradient(circle, rgba(124,58,237,0.10) 0%, transparent 70%)',
        }}
      />

      {/* ── Floating animated orbs ────────────────────────── */}
      <div
        className="absolute top-[15%] left-[10%] w-72 h-72 rounded-full bg-accent-cyan/[0.04] blur-3xl animate-float pointer-events-none"
        style={{ animationDelay: '0s' }}
      />
      <div
        className="absolute top-[60%] right-[8%] w-96 h-96 rounded-full bg-accent-purple/[0.05] blur-3xl animate-float pointer-events-none"
        style={{ animationDelay: '2s' }}
      />
      <div
        className="absolute bottom-[20%] left-[30%] w-64 h-64 rounded-full bg-accent-cyan/[0.03] blur-3xl animate-float pointer-events-none"
        style={{ animationDelay: '4s' }}
      />
      <div
        className="absolute top-[35%] right-[35%] w-48 h-48 rounded-full bg-accent-red/[0.03] blur-3xl animate-float pointer-events-none"
        style={{ animationDelay: '1s' }}
      />

      {/* ── Content ──────────────────────────────────────── */}
      <motion.div
        className="relative z-10 flex flex-col items-center text-center px-6 max-w-5xl mx-auto"
        variants={containerVariants}
        initial="hidden"
        animate="visible"
      >
        {/* Eyebrow */}
        <motion.div variants={fadeUp} className="mb-8">
          <span className="inline-flex items-center gap-2 px-4 py-1.5 rounded-full border border-border-subtle bg-white/[0.03] text-xs font-medium tracking-[0.15em] uppercase text-text-secondary">
            <span className="w-1.5 h-1.5 rounded-full bg-accent-green animate-pulse-glow" />
            Established 2002 — Bangalore, India
          </span>
        </motion.div>

        {/* Main heading */}
        <motion.h1
          variants={fadeUp}
          className="text-5xl sm:text-6xl lg:text-7xl xl:text-8xl font-black tracking-tight leading-[1.05]"
        >
          <span className="gradient-text">Master Cybersecurity.</span>
          <br />
          <span className="gradient-text">Defend the Future.</span>
        </motion.h1>

        {/* Subtitle */}
        <motion.p
          variants={fadeUp}
          className="mt-7 text-lg lg:text-xl text-text-secondary max-w-2xl leading-relaxed"
        >
          Industry-leading certifications, hands-on virtual labs, and expert-led
          training programs. Authorized by Cisco, Microsoft, EC-Council,
          CompTIA, and more.
        </motion.p>

        {/* CTA buttons */}
        <motion.div variants={fadeUp} className="mt-10 flex flex-wrap items-center justify-center gap-4">
          <Link
            href="/training"
            className="group relative inline-flex items-center justify-center px-8 py-4 text-base font-semibold text-bg-primary bg-gradient-to-r from-accent-cyan to-[#06B6D4] rounded-xl overflow-hidden transition-all duration-300 hover:shadow-[0_0_30px_rgba(0,229,255,0.25)] hover:scale-[1.02] active:scale-[0.98]"
          >
            <span className="relative z-10">Explore Programs</span>
            <div className="absolute inset-0 bg-gradient-to-r from-[#06B6D4] to-accent-cyan opacity-0 group-hover:opacity-100 transition-opacity duration-300" />
          </Link>
          <Link
            href="/certifications"
            className="inline-flex items-center justify-center px-8 py-4 text-base font-semibold text-text-primary border border-border-subtle rounded-xl bg-white/[0.03] backdrop-blur-sm transition-all duration-300 hover:border-border-hover hover:bg-white/[0.06] hover:scale-[1.02] active:scale-[0.98]"
          >
            View Certifications
          </Link>
        </motion.div>

        {/* Vendor strip */}
        <motion.div
          variants={fadeUp}
          className="mt-16 flex items-center gap-2 text-sm text-text-muted"
        >
          {['Cisco', 'EC-Council', 'CompTIA', 'Microsoft', 'AWS', 'Fortinet'].map(
            (name, i) => (
              <span key={name} className="flex items-center gap-2">
                {i > 0 && <span className="text-white/20">•</span>}
                <span className="hover:text-text-secondary transition-colors duration-300">
                  {name}
                </span>
              </span>
            )
          )}
        </motion.div>
      </motion.div>

      {/* ── Scroll indicator ─────────────────────────────── */}
      <motion.div
        className="absolute bottom-10 left-1/2 -translate-x-1/2 flex flex-col items-center gap-2"
        initial={{ opacity: 0 }}
        animate={{ opacity: 1 }}
        transition={{ delay: 2, duration: 1 }}
      >
        <span className="text-[11px] uppercase tracking-[0.2em] text-text-muted">
          Scroll
        </span>
        <motion.div
          animate={{ y: [0, 6, 0] }}
          transition={{ duration: 1.8, repeat: Infinity, ease: 'easeInOut' }}
        >
          <ChevronDown className="w-5 h-5 text-text-muted" />
        </motion.div>
      </motion.div>
    </section>
  );
}
