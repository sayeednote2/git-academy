'use client';

import { useEffect, useRef, useState } from 'react';
import { motion, useInView } from 'framer-motion';
import { stats } from '@/lib/data';

function AnimatedCounter({
  target,
  suffix,
  label,
}: {
  target: number;
  suffix: string;
  label: string;
}) {
  const ref = useRef<HTMLDivElement>(null);
  const isInView = useInView(ref, { once: true, margin: '-50px' });
  const [count, setCount] = useState(0);

  useEffect(() => {
    if (!isInView) return;

    let start = 0;
    const duration = 2000;
    const increment = target / (duration / 16);
    const timer = setInterval(() => {
      start += increment;
      if (start >= target) {
        setCount(target);
        clearInterval(timer);
      } else {
        setCount(Math.floor(start));
      }
    }, 16);

    return () => clearInterval(timer);
  }, [isInView, target]);

  return (
    <div ref={ref} className="text-center">
      <div className="text-5xl lg:text-6xl font-black gradient-text tabular-nums">
        {count.toLocaleString()}
        {suffix}
      </div>
      <div className="mt-3 text-sm text-text-secondary uppercase tracking-wider font-medium">
        {label}
      </div>
    </div>
  );
}

export function StatsSection() {
  return (
    <section className="relative py-24 lg:py-32 bg-gradient-to-r from-bg-secondary via-bg-tertiary to-bg-secondary overflow-hidden">
      {/* Cyber grid overlay */}
      <div className="absolute inset-0 cyber-grid pointer-events-none" />

      {/* Subtle gradient accents */}
      <div
        className="absolute top-0 left-1/4 w-[500px] h-[300px] pointer-events-none"
        style={{
          background:
            'radial-gradient(ellipse, rgba(0,229,255,0.05) 0%, transparent 70%)',
        }}
      />

      <motion.div
        className="relative z-10 max-w-6xl mx-auto px-6"
        initial={{ opacity: 0, y: 30 }}
        whileInView={{ opacity: 1, y: 0 }}
        viewport={{ once: true, margin: '-60px' }}
        transition={{ duration: 0.6, ease: [0.16, 1, 0.3, 1] }}
      >
        <div className="grid grid-cols-2 lg:grid-cols-4 gap-12 lg:gap-8">
          {stats.map((stat) => (
            <AnimatedCounter
              key={stat.label}
              target={stat.value}
              suffix={stat.suffix}
              label={stat.label}
            />
          ))}
        </div>
      </motion.div>
    </section>
  );
}
