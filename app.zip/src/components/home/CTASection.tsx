'use client';

import { motion } from 'framer-motion';
import Link from 'next/link';
import { ArrowRight } from 'lucide-react';

export function CTASection() {
  return (
    <section className="relative py-24 lg:py-32 overflow-hidden">
      {/* ── Background gradients ─────────────────────────── */}
      <div className="absolute inset-0 bg-gradient-to-br from-accent-cyan/[0.06] via-transparent to-accent-purple/[0.06]" />
      <div className="absolute inset-0 cyber-grid pointer-events-none" />

      {/* Ambient orbs */}
      <div
        className="absolute top-1/2 left-1/2 -translate-x-1/2 -translate-y-1/2 w-[600px] h-[600px] rounded-full pointer-events-none"
        style={{
          background:
            'radial-gradient(circle, rgba(0,229,255,0.06) 0%, transparent 65%)',
        }}
      />

      <motion.div
        className="relative z-10 max-w-3xl mx-auto px-6 text-center"
        initial={{ opacity: 0, y: 30 }}
        whileInView={{ opacity: 1, y: 0 }}
        viewport={{ once: true, margin: '-60px' }}
        transition={{ duration: 0.7, ease: [0.16, 1, 0.3, 1] }}
      >
        <h2 className="text-3xl lg:text-5xl font-bold text-text-primary leading-tight">
          Ready to Advance Your{' '}
          <span className="gradient-text">Security Career</span>?
        </h2>

        <p className="mt-6 text-lg text-text-secondary max-w-2xl mx-auto leading-relaxed">
          Join thousands of professionals who have transformed their careers
          with GIT Academy. Start your journey with industry-recognized
          certifications and hands-on training.
        </p>

        <div className="mt-10 flex flex-wrap items-center justify-center gap-4">
          <Link
            href="/training"
            className="group relative inline-flex items-center justify-center gap-2 px-8 py-4 text-base font-semibold text-bg-primary bg-gradient-to-r from-accent-cyan to-[#06B6D4] rounded-xl overflow-hidden transition-all duration-300 hover:shadow-[0_0_30px_rgba(0,229,255,0.25)] hover:scale-[1.02] active:scale-[0.98]"
          >
            <span className="relative z-10">Start Learning Today</span>
            <ArrowRight className="w-4 h-4 relative z-10 transition-transform duration-300 group-hover:translate-x-0.5" />
            <div className="absolute inset-0 bg-gradient-to-r from-[#06B6D4] to-accent-cyan opacity-0 group-hover:opacity-100 transition-opacity duration-300" />
          </Link>
          <Link
            href="/contact"
            className="inline-flex items-center justify-center px-8 py-4 text-base font-semibold text-text-primary border border-border-subtle rounded-xl bg-white/[0.03] backdrop-blur-sm transition-all duration-300 hover:border-border-hover hover:bg-white/[0.06] hover:scale-[1.02] active:scale-[0.98]"
          >
            Talk to an Advisor
          </Link>
        </div>
      </motion.div>
    </section>
  );
}
