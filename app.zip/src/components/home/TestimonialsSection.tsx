'use client';

import { motion } from 'framer-motion';
import { Star, Quote } from 'lucide-react';
import { testimonials } from '@/lib/data';

const containerVariants = {
  hidden: {},
  visible: {
    transition: {
      staggerChildren: 0.12,
    },
  },
};

const cardVariants = {
  hidden: { opacity: 0, y: 30 },
  visible: {
    opacity: 1,
    y: 0,
    transition: { duration: 0.6, ease: [0.16, 1, 0.3, 1] as const },
  },
};

export function TestimonialsSection() {
  const displayTestimonials = testimonials.slice(0, 3);

  return (
    <section className="relative py-24 lg:py-32 bg-bg-secondary/30">
      <div className="max-w-7xl mx-auto px-6">
        {/* Section header */}
        <div className="text-center mb-16">
          <span className="text-xs uppercase tracking-[0.2em] text-accent-cyan font-medium">
            Student Success
          </span>
          <h2 className="mt-4 text-3xl lg:text-4xl font-bold text-text-primary">
            What Our Students Say
          </h2>
        </div>

        {/* Testimonial cards */}
        <motion.div
          className="grid grid-cols-1 md:grid-cols-3 gap-6"
          variants={containerVariants}
          initial="hidden"
          whileInView="visible"
          viewport={{ once: true, margin: '-60px' }}
        >
          {displayTestimonials.map((testimonial) => (
            <motion.div
              key={testimonial.name}
              variants={cardVariants}
              className="glass glass-hover rounded-2xl p-8 flex flex-col relative"
            >
              {/* Quote icon */}
              <Quote className="w-8 h-8 text-accent-cyan/20 mb-4" />

              {/* Stars */}
              <div className="flex gap-0.5 mb-5">
                {Array.from({ length: 5 }).map((_, i) => (
                  <Star
                    key={i}
                    className={`w-4 h-4 ${
                      i < testimonial.rating
                        ? 'text-accent-amber fill-accent-amber'
                        : 'text-text-muted'
                    }`}
                  />
                ))}
              </div>

              {/* Quote */}
              <p className="text-text-secondary leading-relaxed italic flex-1">
                &ldquo;{testimonial.quote}&rdquo;
              </p>

              {/* Author */}
              <div className="mt-6 pt-5 border-t border-border-subtle">
                <div className="flex items-center justify-between">
                  <div>
                    <div className="font-semibold text-text-primary text-sm">
                      {testimonial.name}
                    </div>
                    <div className="text-xs text-text-muted mt-0.5">
                      {testimonial.role} · {testimonial.company}
                    </div>
                  </div>
                  <span className="px-3 py-1 text-[10px] font-semibold uppercase tracking-wider text-accent-cyan bg-accent-cyan/10 rounded-full border border-accent-cyan/20">
                    {testimonial.course}
                  </span>
                </div>
              </div>
            </motion.div>
          ))}
        </motion.div>
      </div>
    </section>
  );
}
