'use client';

import { useState, useMemo } from 'react';
import { motion, AnimatePresence } from 'framer-motion';
import { ArrowRight, Clock } from 'lucide-react';
import Link from 'next/link';
import { allCourses, vendors } from '@/lib/data';
import type { CourseLevel } from '@/lib/data';

const tabs = [
  { key: 'all', label: 'All' },
  { key: 'cisco', label: 'Cisco' },
  { key: 'ec-council', label: 'EC-Council' },
  { key: 'comptia', label: 'CompTIA' },
  { key: 'microsoft', label: 'Microsoft' },
  { key: 'cloud', label: 'Cloud' },
  { key: 'security', label: 'Security' },
];

const levelColors: Record<CourseLevel, string> = {
  Beginner: 'bg-accent-green/15 text-accent-green border-accent-green/20',
  Intermediate: 'bg-accent-cyan/15 text-accent-cyan border-accent-cyan/20',
  Advanced: 'bg-accent-purple/15 text-accent-purple border-accent-purple/20',
  Expert: 'bg-accent-red/15 text-accent-red border-accent-red/20',
};

function getVendorColor(vendorSlug: string): string {
  const vendor = vendors.find((v) => v.slug === vendorSlug);
  return vendor?.color ?? '#00E5FF';
}

export function CourseShowcase() {
  const [activeTab, setActiveTab] = useState('all');

  const filteredCourses = useMemo(() => {
    let courses = allCourses;

    switch (activeTab) {
      case 'all':
        break;
      case 'cloud':
        courses = allCourses.filter(
          (c) =>
            c.category.toLowerCase().includes('cloud') ||
            c.vendorSlug === 'aws'
        );
        break;
      case 'security':
        courses = allCourses.filter(
          (c) =>
            c.category.toLowerCase().includes('security') ||
            c.category.toLowerCase().includes('hacking') ||
            c.category.toLowerCase().includes('penetration') ||
            c.category.toLowerCase().includes('forensics') ||
            c.category.toLowerCase().includes('soc')
        );
        break;
      default:
        courses = allCourses.filter((c) => c.vendorSlug === activeTab);
    }

    return courses.slice(0, 6);
  }, [activeTab]);

  return (
    <section className="relative py-24 lg:py-32 bg-bg-secondary/30">
      <div className="max-w-7xl mx-auto px-6">
        {/* Section header */}
        <div className="text-center mb-12">
          <span className="text-xs uppercase tracking-[0.2em] text-accent-cyan font-medium">
            Training Programs
          </span>
          <h2 className="mt-4 text-3xl lg:text-4xl font-bold text-text-primary">
            Industry-Leading Courses
          </h2>
        </div>

        {/* Tab bar */}
        <div className="flex justify-center mb-12">
          <div className="flex gap-1 overflow-x-auto pb-1 scrollbar-none max-w-full">
            {tabs.map((tab) => (
              <button
                key={tab.key}
                onClick={() => setActiveTab(tab.key)}
                className={`relative px-5 py-2.5 text-sm font-medium rounded-lg transition-colors duration-300 whitespace-nowrap ${
                  activeTab === tab.key
                    ? 'text-white'
                    : 'text-text-muted hover:text-text-secondary'
                }`}
              >
                {activeTab === tab.key && (
                  <motion.div
                    layoutId="activeTab"
                    className="absolute inset-0 bg-white/[0.08] border border-border-subtle rounded-lg"
                    transition={{ type: 'spring', stiffness: 380, damping: 30 }}
                  />
                )}
                <span className="relative z-10">{tab.label}</span>
                {activeTab === tab.key && (
                  <motion.div
                    layoutId="activeTabIndicator"
                    className="absolute -bottom-0.5 left-1/2 -translate-x-1/2 w-8 h-0.5 bg-accent-cyan rounded-full"
                    transition={{ type: 'spring', stiffness: 380, damping: 30 }}
                  />
                )}
              </button>
            ))}
          </div>
        </div>

        {/* Course grid */}
        <AnimatePresence mode="wait">
          <motion.div
            key={activeTab}
            initial={{ opacity: 0, y: 16 }}
            animate={{ opacity: 1, y: 0 }}
            exit={{ opacity: 0, y: -16 }}
            transition={{ duration: 0.35, ease: [0.16, 1, 0.3, 1] }}
            className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6"
          >
            {filteredCourses.map((course) => (
              <div
                key={course.id}
                className="glass glass-hover rounded-2xl p-6 flex flex-col group"
              >
                {/* Vendor indicator + category */}
                <div className="flex items-center gap-3 mb-4">
                  <span
                    className="w-2 h-2 rounded-full shrink-0"
                    style={{ backgroundColor: getVendorColor(course.vendorSlug) }}
                  />
                  <span className="text-xs text-text-muted font-medium uppercase tracking-wider">
                    {course.vendor}
                  </span>
                </div>

                {/* Title */}
                <h3 className="text-lg font-semibold text-text-primary mb-2 line-clamp-2 group-hover:text-accent-cyan transition-colors duration-300">
                  {course.title}
                </h3>

                {/* Description */}
                <p className="text-sm text-text-secondary leading-relaxed line-clamp-2 mb-6 flex-1">
                  {course.description}
                </p>

                {/* Bottom row */}
                <div className="flex items-center justify-between pt-4 border-t border-border-subtle">
                  <div className="flex items-center gap-3">
                    <span
                      className={`inline-flex px-3 py-1 text-xs font-medium rounded-full border ${levelColors[course.level]}`}
                    >
                      {course.level}
                    </span>
                    <span className="inline-flex items-center gap-1 text-xs text-text-muted">
                      <Clock className="w-3.5 h-3.5" />
                      {course.duration}
                    </span>
                  </div>
                  <Link
                    href={`/training/${course.vendorSlug}/${course.slug}`}
                    className="text-sm font-medium text-accent-cyan hover:text-white transition-colors duration-300 flex items-center gap-1 group/link"
                  >
                    Learn More
                    <ArrowRight className="w-3.5 h-3.5 transition-transform duration-300 group-hover/link:translate-x-0.5" />
                  </Link>
                </div>
              </div>
            ))}
          </motion.div>
        </AnimatePresence>

        {/* View All link */}
        <div className="text-center mt-12">
          <Link
            href="/training"
            className="inline-flex items-center gap-2 text-accent-cyan hover:text-white font-medium transition-colors duration-300 group"
          >
            View All Programs
            <ArrowRight className="w-4 h-4 transition-transform duration-300 group-hover:translate-x-1" />
          </Link>
        </div>
      </div>
    </section>
  );
}
