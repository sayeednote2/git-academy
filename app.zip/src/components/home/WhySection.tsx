'use client';

import { motion } from 'framer-motion';
import { Shield, Monitor, Award, Users } from 'lucide-react';

const features = [
  {
    icon: Shield,
    title: 'Authorized Training',
    description:
      'Official training partner for Cisco, Microsoft, AWS, CompTIA, EC-Council, Red Hat, and more.',
  },
  {
    icon: Monitor,
    title: 'Hands-on Labs',
    description:
      'Industry-standard hardware and software lab environments with 24/7 remote access for real-world practice.',
  },
  {
    icon: Award,
    title: '95% Pass Rate',
    description:
      'Our structured methodology and expert instructors deliver one of the highest certification pass rates in India.',
  },
  {
    icon: Users,
    title: 'Expert Instructors',
    description:
      'Learn from CCIE, CEH Master, and AWS certified professionals with 15+ years of industry experience.',
  },
];

const containerVariants = {
  hidden: {},
  visible: {
    transition: {
      staggerChildren: 0.12,
    },
  },
};

const cardVariants = {
  hidden: { opacity: 0, y: 40 },
  visible: {
    opacity: 1,
    y: 0,
    transition: { duration: 0.6, ease: [0.16, 1, 0.3, 1] as const },
  },
};

export function WhySection() {
  return (
    <section className="relative py-24 lg:py-32">
      <div className="max-w-7xl mx-auto px-6">
        {/* Section header */}
        <div className="text-center mb-16">
          <span className="text-xs uppercase tracking-[0.2em] text-accent-cyan font-medium">
            Why GIT Academy
          </span>
          <h2 className="mt-4 text-3xl lg:text-4xl font-bold text-text-primary">
            Built for Security Professionals
          </h2>
          <p className="mt-4 text-text-secondary max-w-xl mx-auto">
            Two decades of focused expertise in cybersecurity and networking
            education, backed by the industry&apos;s leading authorities.
          </p>
        </div>

        {/* Feature cards grid */}
        <motion.div
          className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6"
          variants={containerVariants}
          initial="hidden"
          whileInView="visible"
          viewport={{ once: true, margin: '-80px' }}
        >
          {features.map((feature) => {
            const Icon = feature.icon;
            return (
              <motion.div
                key={feature.title}
                variants={cardVariants}
                className="glass glass-hover rounded-2xl p-8 group"
              >
                <div className="w-12 h-12 rounded-xl bg-accent-cyan/10 flex items-center justify-center mb-5 group-hover:bg-accent-cyan/[0.15] transition-colors duration-300">
                  <Icon className="w-6 h-6 text-accent-cyan" />
                </div>
                <h3 className="text-lg font-semibold text-text-primary mb-2">
                  {feature.title}
                </h3>
                <p className="text-sm text-text-secondary leading-relaxed">
                  {feature.description}
                </p>
              </motion.div>
            );
          })}
        </motion.div>
      </div>
    </section>
  );
}
