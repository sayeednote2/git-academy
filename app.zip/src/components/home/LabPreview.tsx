'use client';

import { useEffect, useRef, useState, useCallback } from 'react';
import { motion, useInView } from 'framer-motion';
import { CheckCircle, ArrowRight } from 'lucide-react';
import Link from 'next/link';

const terminalLines = [
  { prompt: '$ ', text: 'nmap -sV -sC 10.10.10.1', delay: 0 },
  { prompt: '', text: 'Starting Nmap 7.94 ( https://nmap.org )', delay: 800 },
  { prompt: '$ ', text: 'msfconsole', delay: 1600 },
  { prompt: 'msf6 > ', text: 'use exploit/multi/handler', delay: 2400 },
  { prompt: 'msf6 > ', text: 'set LHOST 10.10.14.5', delay: 3200 },
  { prompt: '$ ', text: 'python3 exploit.py --target 10.10.10.1', delay: 4000 },
  { prompt: '', text: '[+] Shell obtained — root@10.10.10.1', delay: 4800 },
];

const labFeatures = [
  '24/7 Remote Lab Access',
  'Real Enterprise Hardware',
  'Guided Attack Scenarios',
  'Certification Practice Exams',
];

export function LabPreview() {
  const sectionRef = useRef<HTMLDivElement>(null);
  const isInView = useInView(sectionRef, { once: true, margin: '-100px' });
  const [visibleLines, setVisibleLines] = useState(0);
  const hasStarted = useRef(false);

  const startAnimation = useCallback(() => {
    if (hasStarted.current) return;
    hasStarted.current = true;
    terminalLines.forEach((line, i) => {
      setTimeout(() => setVisibleLines(i + 1), line.delay);
    });
  }, []);

  useEffect(() => {
    if (isInView) startAnimation();
  }, [isInView, startAnimation]);

  return (
    <section ref={sectionRef} className="relative py-24 lg:py-32">
      <div className="max-w-7xl mx-auto px-6">
        <div className="grid grid-cols-1 lg:grid-cols-2 gap-12 lg:gap-16 items-center">
          {/* ── Terminal mockup ─────────────────────────── */}
          <motion.div
            initial={{ opacity: 0, x: -40 }}
            whileInView={{ opacity: 1, x: 0 }}
            viewport={{ once: true, margin: '-80px' }}
            transition={{ duration: 0.7, ease: [0.16, 1, 0.3, 1] }}
          >
            <div className="glass rounded-2xl overflow-hidden shadow-2xl shadow-black/30">
              {/* Title bar */}
              <div className="flex items-center gap-2 px-5 py-3.5 bg-white/[0.03] border-b border-border-subtle">
                <div className="flex items-center gap-1.5">
                  <span className="w-3 h-3 rounded-full bg-[#FF5F57]" />
                  <span className="w-3 h-3 rounded-full bg-[#FEBC2E]" />
                  <span className="w-3 h-3 rounded-full bg-[#28C840]" />
                </div>
                <span className="ml-3 text-xs text-text-muted font-mono">
                  kali@gitlab ~ / pentest
                </span>
              </div>

              {/* Terminal content */}
              <div className="p-5 min-h-[280px] font-mono text-sm leading-7">
                {terminalLines.slice(0, visibleLines).map((line, i) => (
                  <div key={i} className="flex">
                    {line.prompt && (
                      <span className="text-accent-green shrink-0">
                        {line.prompt}
                      </span>
                    )}
                    <span
                      className={
                        line.prompt
                          ? 'text-text-primary'
                          : line.text.startsWith('[+]')
                          ? 'text-accent-green'
                          : 'text-text-muted'
                      }
                    >
                      {line.text}
                    </span>
                  </div>
                ))}
                {/* Blinking cursor */}
                {visibleLines < terminalLines.length && (
                  <span className="inline-block w-2 h-4 bg-accent-cyan animate-pulse-glow" />
                )}
                {visibleLines >= terminalLines.length && (
                  <div className="flex items-center">
                    <span className="text-accent-green">$ </span>
                    <span className="inline-block w-2 h-4 bg-accent-cyan animate-pulse-glow ml-0.5" />
                  </div>
                )}
              </div>
            </div>
          </motion.div>

          {/* ── Content side ───────────────────────────── */}
          <motion.div
            initial={{ opacity: 0, x: 40 }}
            whileInView={{ opacity: 1, x: 0 }}
            viewport={{ once: true, margin: '-80px' }}
            transition={{ duration: 0.7, ease: [0.16, 1, 0.3, 1], delay: 0.15 }}
          >
            <span className="text-xs uppercase tracking-[0.2em] text-accent-cyan font-medium">
              Virtual Labs
            </span>
            <h2 className="mt-4 text-3xl lg:text-4xl font-bold text-text-primary">
              Real-World Virtual Labs
            </h2>
            <p className="mt-5 text-text-secondary leading-relaxed max-w-lg">
              Practice on enterprise-grade infrastructure with our fully equipped
              virtual lab environments. From network penetration testing to cloud
              security — train on the same tools the professionals use.
            </p>

            <ul className="mt-8 space-y-4">
              {labFeatures.map((feature) => (
                <li key={feature} className="flex items-center gap-3">
                  <CheckCircle className="w-5 h-5 text-accent-green shrink-0" />
                  <span className="text-text-primary font-medium">
                    {feature}
                  </span>
                </li>
              ))}
            </ul>

            <Link
              href="/labs"
              className="mt-10 inline-flex items-center gap-2 px-7 py-3.5 text-sm font-semibold text-bg-primary bg-gradient-to-r from-accent-cyan to-[#06B6D4] rounded-xl transition-all duration-300 hover:shadow-[0_0_25px_rgba(0,229,255,0.2)] hover:scale-[1.02] active:scale-[0.98] group"
            >
              Explore Lab Environment
              <ArrowRight className="w-4 h-4 transition-transform duration-300 group-hover:translate-x-0.5" />
            </Link>
          </motion.div>
        </div>
      </div>
    </section>
  );
}
