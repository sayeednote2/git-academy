'use client';

import { motion } from 'framer-motion';
import { ArrowRight, Clock, User } from 'lucide-react';
import Link from 'next/link';
import { blogPosts } from '@/lib/data';

const containerVariants = {
  hidden: {},
  visible: {
    transition: {
      staggerChildren: 0.12,
    },
  },
};

const cardVariants = {
  hidden: { opacity: 0, y: 30 },
  visible: {
    opacity: 1,
    y: 0,
    transition: { duration: 0.6, ease: [0.16, 1, 0.3, 1] as const },
  },
};

const categoryColors: Record<string, string> = {
  'Industry Trends': 'bg-accent-purple/15 text-accent-purple border-accent-purple/20',
  'Career Guides': 'bg-accent-cyan/15 text-accent-cyan border-accent-cyan/20',
  Tutorials: 'bg-accent-green/15 text-accent-green border-accent-green/20',
};

function formatDate(dateStr: string): string {
  const d = new Date(dateStr);
  return d.toLocaleDateString('en-US', {
    month: 'short',
    day: 'numeric',
    year: 'numeric',
  });
}

export function BlogPreview() {
  return (
    <section className="relative py-24 lg:py-32">
      <div className="max-w-7xl mx-auto px-6">
        {/* Section header */}
        <div className="flex items-end justify-between mb-12">
          <div>
            <span className="text-xs uppercase tracking-[0.2em] text-accent-cyan font-medium">
              From the Blog
            </span>
            <h2 className="mt-4 text-3xl lg:text-4xl font-bold text-text-primary">
              Latest Insights
            </h2>
          </div>
          <Link
            href="/blog"
            className="hidden md:inline-flex items-center gap-2 text-accent-cyan hover:text-white font-medium text-sm transition-colors duration-300 group"
          >
            View All
            <ArrowRight className="w-4 h-4 transition-transform duration-300 group-hover:translate-x-1" />
          </Link>
        </div>

        {/* Blog cards */}
        <motion.div
          className="grid grid-cols-1 md:grid-cols-3 gap-6"
          variants={containerVariants}
          initial="hidden"
          whileInView="visible"
          viewport={{ once: true, margin: '-60px' }}
        >
          {blogPosts.map((post) => (
            <motion.article
              key={post.id}
              variants={cardVariants}
              className="glass glass-hover rounded-2xl overflow-hidden flex flex-col group"
            >
              {/* Gradient accent bar */}
              <div className="h-0.5 bg-gradient-to-r from-accent-cyan via-accent-purple to-accent-red" />

              <div className="p-7 flex flex-col flex-1">
                {/* Category badge */}
                <span
                  className={`inline-flex self-start px-3 py-1 text-[10px] font-semibold uppercase tracking-wider rounded-full border mb-5 ${
                    categoryColors[post.category] ??
                    'bg-accent-cyan/15 text-accent-cyan border-accent-cyan/20'
                  }`}
                >
                  {post.category}
                </span>

                {/* Title */}
                <h3 className="text-lg font-semibold text-text-primary leading-snug line-clamp-2 group-hover:text-accent-cyan transition-colors duration-300">
                  <Link href={`/blog/${post.slug}`}>{post.title}</Link>
                </h3>

                {/* Excerpt */}
                <p className="mt-3 text-sm text-text-secondary leading-relaxed line-clamp-3 flex-1">
                  {post.excerpt}
                </p>

                {/* Meta */}
                <div className="mt-6 pt-4 border-t border-border-subtle flex items-center gap-4 text-xs text-text-muted">
                  <span className="flex items-center gap-1.5">
                    <User className="w-3.5 h-3.5" />
                    {post.author}
                  </span>
                  <span>{formatDate(post.date)}</span>
                  <span className="flex items-center gap-1.5 ml-auto">
                    <Clock className="w-3.5 h-3.5" />
                    {post.readTime}
                  </span>
                </div>
              </div>
            </motion.article>
          ))}
        </motion.div>

        {/* Mobile view all link */}
        <div className="text-center mt-10 md:hidden">
          <Link
            href="/blog"
            className="inline-flex items-center gap-2 text-accent-cyan hover:text-white font-medium text-sm transition-colors duration-300"
          >
            View All Posts
            <ArrowRight className="w-4 h-4" />
          </Link>
        </div>
      </div>
    </section>
  );
}
