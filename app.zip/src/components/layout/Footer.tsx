import Link from 'next/link';
import { Shield, Phone, Mail, MapPin } from 'lucide-react';

/* ─── Inline Brand SVG Icons (Lucide doesn't ship brand icons) ── */
function IconLinkedin({ className }: { className?: string }) {
  return (
    <svg className={className} viewBox="0 0 24 24" fill="currentColor">
      <path d="M20.447 20.452h-3.554v-5.569c0-1.328-.027-3.037-1.852-3.037-1.853 0-2.136 1.445-2.136 2.939v5.667H9.351V9h3.414v1.561h.046c.477-.9 1.637-1.85 3.37-1.85 3.601 0 4.267 2.37 4.267 5.455v6.286zM5.337 7.433a2.062 2.062 0 01-2.063-2.065 2.064 2.064 0 112.063 2.065zm1.782 13.019H3.555V9h3.564v11.452zM22.225 0H1.771C.792 0 0 .774 0 1.729v20.542C0 23.227.792 24 1.771 24h20.451C23.2 24 24 23.227 24 22.271V1.729C24 .774 23.2 0 22.222 0h.003z" />
    </svg>
  );
}

function IconX({ className }: { className?: string }) {
  return (
    <svg className={className} viewBox="0 0 24 24" fill="currentColor">
      <path d="M18.244 2.25h3.308l-7.227 8.26 8.502 11.24H16.17l-5.214-6.817L4.99 21.75H1.68l7.73-8.835L1.254 2.25H8.08l4.713 6.231zm-1.161 17.52h1.833L7.084 4.126H5.117z" />
    </svg>
  );
}

function IconYouTube({ className }: { className?: string }) {
  return (
    <svg className={className} viewBox="0 0 24 24" fill="currentColor">
      <path d="M23.498 6.186a3.016 3.016 0 00-2.122-2.136C19.505 3.545 12 3.545 12 3.545s-7.505 0-9.377.505A3.017 3.017 0 00.502 6.186C0 8.07 0 12 0 12s0 3.93.502 5.814a3.016 3.016 0 002.122 2.136c1.871.505 9.376.505 9.376.505s7.505 0 9.377-.505a3.015 3.015 0 002.122-2.136C24 15.93 24 12 24 12s0-3.93-.502-5.814zM9.545 15.568V8.432L15.818 12l-6.273 3.568z" />
    </svg>
  );
}

function IconFacebook({ className }: { className?: string }) {
  return (
    <svg className={className} viewBox="0 0 24 24" fill="currentColor">
      <path d="M24 12.073c0-6.627-5.373-12-12-12s-12 5.373-12 12c0 5.99 4.388 10.954 10.125 11.854v-8.385H7.078v-3.47h3.047V9.43c0-3.007 1.792-4.669 4.533-4.669 1.312 0 2.686.235 2.686.235v2.953H15.83c-1.491 0-1.956.925-1.956 1.874v2.25h3.328l-.532 3.47h-2.796v8.385C19.612 23.027 24 18.062 24 12.073z" />
    </svg>
  );
}

/* ─── Footer Data ─────────────────────────────────────────────── */
const trainingLinks = [
  { label: 'Cisco', href: '/training?vendor=cisco' },
  { label: 'EC-Council', href: '/training?vendor=ec-council' },
  { label: 'CompTIA', href: '/training?vendor=comptia' },
  { label: 'Microsoft', href: '/training?vendor=microsoft' },
  { label: 'AWS', href: '/training?vendor=aws' },
  { label: 'Fortinet', href: '/training?vendor=fortinet' },
];

const companyLinks = [
  { label: 'About', href: '/about' },
  { label: 'Certifications', href: '/certifications' },
  { label: 'Virtual Labs', href: '/labs' },
  { label: 'Blog', href: '/blog' },
  { label: 'Careers', href: '/careers' },
  { label: 'Contact', href: '/contact' },
];

const socialLinks = [
  { icon: IconLinkedin, href: 'https://linkedin.com', label: 'LinkedIn' },
  { icon: IconX, href: 'https://x.com', label: 'X (Twitter)' },
  { icon: IconYouTube, href: 'https://youtube.com', label: 'YouTube' },
  { icon: IconFacebook, href: 'https://facebook.com', label: 'Facebook' },
];

/* ─── Footer Component ────────────────────────────────────────── */
export function Footer() {
  return (
    <footer className="relative bg-bg-secondary">
      {/* ── Gradient divider ── */}
      <div className="section-divider" />

      {/* ── Main grid ── */}
      <div className="max-w-7xl mx-auto px-6 pt-16 pb-12">
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-12 lg:gap-8">

          {/* ── Col 1 — Brand ── */}
          <div className="lg:col-span-1">
            {/* Logo */}
            <Link href="/" className="inline-flex items-center gap-2.5 group">
              <div className="relative flex items-center justify-center w-9 h-9">
                <div className="absolute inset-0 rounded-lg bg-accent-cyan/10" />
                <Shield className="w-5 h-5 text-accent-cyan relative z-10" strokeWidth={2.5} />
              </div>
              <div className="flex items-baseline gap-0.5">
                <span className="text-xl font-bold text-accent-cyan tracking-tight">GIT</span>
                <span className="text-xl font-semibold text-text-primary tracking-tight">Academy</span>
              </div>
            </Link>

            {/* Tagline */}
            <p className="mt-4 text-sm font-medium text-text-primary/90 leading-relaxed">
              Master Cybersecurity.
              <br />
              Defend the Future.
            </p>

            {/* Description */}
            <p className="mt-3 text-sm text-text-secondary leading-relaxed max-w-xs">
              Premier cybersecurity training institute since 2002. Authorized partner for Cisco,
              Microsoft, AWS, CompTIA, EC-Council &amp; Red Hat.
            </p>

            {/* Social icons */}
            <div className="flex items-center gap-2 mt-6">
              {socialLinks.map((social) => (
                <a
                  key={social.label}
                  href={social.href}
                  target="_blank"
                  rel="noopener noreferrer"
                  aria-label={social.label}
                  className="w-9 h-9 rounded-lg flex items-center justify-center text-text-muted hover:text-accent-cyan hover:bg-accent-cyan/[0.08] border border-transparent hover:border-accent-cyan/20 transition-all duration-300"
                >
                  <social.icon className="w-4 h-4" />
                </a>
              ))}
            </div>
          </div>

          {/* ── Col 2 — Training ── */}
          <div>
            <h3 className="text-sm font-semibold uppercase tracking-[0.15em] text-text-primary mb-5">
              Training
            </h3>
            <ul className="space-y-3">
              {trainingLinks.map((link) => (
                <li key={link.label}>
                  <Link
                    href={link.href}
                    className="text-sm text-text-secondary hover:text-white hover:translate-x-0.5 transition-all duration-200 inline-block"
                  >
                    {link.label}
                  </Link>
                </li>
              ))}
            </ul>
          </div>

          {/* ── Col 3 — Company ── */}
          <div>
            <h3 className="text-sm font-semibold uppercase tracking-[0.15em] text-text-primary mb-5">
              Company
            </h3>
            <ul className="space-y-3">
              {companyLinks.map((link) => (
                <li key={link.label}>
                  <Link
                    href={link.href}
                    className="text-sm text-text-secondary hover:text-white hover:translate-x-0.5 transition-all duration-200 inline-block"
                  >
                    {link.label}
                  </Link>
                </li>
              ))}
            </ul>
          </div>

          {/* ── Col 4 — Contact ── */}
          <div>
            <h3 className="text-sm font-semibold uppercase tracking-[0.15em] text-text-primary mb-5">
              Contact
            </h3>
            <ul className="space-y-4">
              <li>
                <a
                  href="tel:+919972177745"
                  className="flex items-start gap-3 text-sm text-text-secondary hover:text-white transition-colors duration-200 group"
                >
                  <Phone className="w-4 h-4 mt-0.5 text-accent-cyan/60 group-hover:text-accent-cyan shrink-0 transition-colors" />
                  <span>+91 99721 77745</span>
                </a>
              </li>
              <li>
                <a
                  href="mailto:info@gitinfo.com"
                  className="flex items-start gap-3 text-sm text-text-secondary hover:text-white transition-colors duration-200 group"
                >
                  <Mail className="w-4 h-4 mt-0.5 text-accent-cyan/60 group-hover:text-accent-cyan shrink-0 transition-colors" />
                  <span>info@gitinfo.com</span>
                </a>
              </li>
              <li>
                <div className="flex items-start gap-3 text-sm text-text-secondary">
                  <MapPin className="w-4 h-4 mt-0.5 text-accent-cyan/60 shrink-0" />
                  <span className="leading-relaxed">
                    No 72, TSN Arcade,<br />
                    28th Main Road, Jayanagar,<br />
                    Bengaluru, India
                  </span>
                </div>
              </li>
            </ul>
          </div>
        </div>
      </div>

      {/* ── Bottom bar ── */}
      <div className="border-t border-white/[0.06]">
        <div className="max-w-7xl mx-auto px-6 py-5 flex flex-col sm:flex-row items-center justify-between gap-3">
          <p className="text-xs text-text-muted">
            © {new Date().getFullYear()} GIT Academy. All rights reserved.
          </p>
          <div className="flex items-center gap-6">
            <Link
              href="/privacy"
              className="text-xs text-text-muted hover:text-text-secondary transition-colors duration-200"
            >
              Privacy Policy
            </Link>
            <span className="w-px h-3 bg-white/10" />
            <Link
              href="/terms"
              className="text-xs text-text-muted hover:text-text-secondary transition-colors duration-200"
            >
              Terms of Service
            </Link>
          </div>
        </div>
      </div>
    </footer>
  );
}
