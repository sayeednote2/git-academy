'use client';

import { useState, useEffect, useCallback } from 'react';
import Link from 'next/link';
import { motion, AnimatePresence } from 'framer-motion';
import { Menu, X, ChevronDown, Shield, ArrowRight } from 'lucide-react';
import { navLinks } from '@/lib/data';
import { cn } from '@/lib/utils';

/* ─── Mega-Menu vendor icon mapping ───────────────────────────── */
const vendorIcons: Record<string, string> = {
  Cisco: '⟁',
  'EC-Council': '⚔',
  CompTIA: '◈',
  'Microsoft Azure': '◆',
  AWS: '▲',
  Fortinet: '⬡',
  'Palo Alto': '◉',
};

const vendorColors: Record<string, string> = {
  Cisco: '#049FD9',
  'EC-Council': '#D42027',
  CompTIA: '#C8202F',
  'Microsoft Azure': '#00A4EF',
  AWS: '#FF9900',
  Fortinet: '#EE3124',
  'Palo Alto': '#FA582D',
};

/* ─── Navbar Component ────────────────────────────────────────── */
export function Navbar() {
  const [scrolled, setScrolled] = useState(false);
  const [mobileOpen, setMobileOpen] = useState(false);
  const [megaMenuOpen, setMegaMenuOpen] = useState(false);
  const [mobileTrainingOpen, setMobileTrainingOpen] = useState(false);

  /* scroll listener */
  useEffect(() => {
    const onScroll = () => setScrolled(window.scrollY > 20);
    window.addEventListener('scroll', onScroll, { passive: true });
    return () => window.removeEventListener('scroll', onScroll);
  }, []);

  /* lock body scroll when mobile menu is open */
  useEffect(() => {
    document.body.style.overflow = mobileOpen ? 'hidden' : '';
    return () => { document.body.style.overflow = ''; };
  }, [mobileOpen]);

  const closeMobile = useCallback(() => {
    setMobileOpen(false);
    setMobileTrainingOpen(false);
  }, []);

  const trainingLink = navLinks.find((l) => l.children);
  const plainLinks = navLinks.filter((l) => !l.children);

  return (
    <>
      <motion.header
        initial={{ y: -100 }}
        animate={{ y: 0 }}
        transition={{ duration: 0.6, ease: [0.16, 1, 0.3, 1] }}
        className={cn(
          'fixed top-0 left-0 right-0 z-50 h-20 transition-all duration-500',
          scrolled
            ? 'bg-bg-primary/80 backdrop-blur-2xl border-b border-white/[0.06] shadow-[0_1px_40px_rgba(0,0,0,0.45)]'
            : 'bg-transparent border-b border-white/[0.04]',
        )}
      >
        {/* ── Accent scan-line at top ── */}
        <div className="absolute top-0 left-0 right-0 h-[1px] bg-gradient-to-r from-transparent via-accent-cyan/20 to-transparent" />

        <nav className="max-w-7xl mx-auto px-6 h-full flex items-center justify-between">
          {/* ── Logo ── */}
          <Link href="/" className="relative group flex items-center gap-2.5 shrink-0">
            <div className="relative flex items-center justify-center w-9 h-9">
              <div className="absolute inset-0 rounded-lg bg-accent-cyan/10 group-hover:bg-accent-cyan/20 transition-colors duration-300" />
              <Shield className="w-5 h-5 text-accent-cyan relative z-10" strokeWidth={2.5} />
            </div>
            <div className="flex items-baseline gap-0.5">
              <span className="text-xl font-bold text-accent-cyan tracking-tight">GIT</span>
              <span className="text-xl font-semibold text-text-primary tracking-tight">Academy</span>
            </div>
            {/* glow on hover */}
            <div className="absolute -inset-3 rounded-2xl bg-accent-cyan/[0.04] opacity-0 group-hover:opacity-100 transition-opacity duration-500 pointer-events-none" />
          </Link>

          {/* ── Desktop Navigation ── */}
          <div className="hidden lg:flex items-center gap-1">
            {/* Training with mega-menu */}
            {trainingLink && (
              <div
                className="relative"
                onMouseEnter={() => setMegaMenuOpen(true)}
                onMouseLeave={() => setMegaMenuOpen(false)}
              >
                <Link
                  href={trainingLink.href}
                  className={cn(
                    'relative flex items-center gap-1 px-4 py-2.5 text-[0.9rem] font-medium rounded-lg transition-all duration-300',
                    'text-text-secondary hover:text-white group',
                  )}
                >
                  <span>{trainingLink.label}</span>
                  <ChevronDown
                    className={cn(
                      'w-3.5 h-3.5 transition-transform duration-300',
                      megaMenuOpen && 'rotate-180',
                    )}
                  />
                  {/* hover underline */}
                  <span className="absolute bottom-1 left-4 right-4 h-px bg-accent-cyan scale-x-0 group-hover:scale-x-100 transition-transform duration-300 origin-left" />
                </Link>

                {/* ── Mega Menu ── */}
                <AnimatePresence>
                  {megaMenuOpen && (
                    <motion.div
                      initial={{ opacity: 0, y: 8, scale: 0.98 }}
                      animate={{ opacity: 1, y: 0, scale: 1 }}
                      exit={{ opacity: 0, y: 8, scale: 0.98 }}
                      transition={{ duration: 0.25, ease: [0.16, 1, 0.3, 1] }}
                      className="absolute top-full left-1/2 -translate-x-1/2 pt-3"
                    >
                      <div className="w-[640px] p-5 rounded-2xl glass border border-white/[0.06] shadow-2xl shadow-black/40">
                        {/* header */}
                        <div className="flex items-center justify-between mb-4 px-1">
                          <p className="text-xs font-semibold uppercase tracking-[0.15em] text-text-muted">
                            Training Vendors
                          </p>
                          <Link
                            href="/training"
                            className="text-xs font-medium text-accent-cyan hover:underline flex items-center gap-1"
                          >
                            View all courses <ArrowRight className="w-3 h-3" />
                          </Link>
                        </div>

                        {/* grid */}
                        <div className="grid grid-cols-2 gap-2">
                          {trainingLink.children!.map((child, i) => (
                            <Link key={child.label} href={child.href}>
                              <motion.div
                                initial={{ opacity: 0, y: 6 }}
                                animate={{ opacity: 1, y: 0 }}
                                transition={{ delay: i * 0.04, duration: 0.25 }}
                                className="group/card flex items-start gap-3.5 p-3.5 rounded-xl transition-all duration-300 hover:bg-white/[0.04] border border-transparent hover:border-white/[0.06]"
                              >
                                {/* vendor icon */}
                                <div
                                  className="shrink-0 w-10 h-10 rounded-lg flex items-center justify-center text-lg font-bold transition-all duration-300"
                                  style={{
                                    background: `${vendorColors[child.label] ?? '#00E5FF'}15`,
                                    color: vendorColors[child.label] ?? '#00E5FF',
                                  }}
                                >
                                  {vendorIcons[child.label] ?? '●'}
                                </div>
                                <div className="min-w-0">
                                  <p className="text-sm font-semibold text-text-primary group-hover/card:text-white transition-colors">
                                    {child.label}
                                  </p>
                                  <p className="text-xs text-text-muted mt-0.5 leading-relaxed">
                                    {child.description}
                                  </p>
                                </div>
                              </motion.div>
                            </Link>
                          ))}
                        </div>

                        {/* footer CTA */}
                        <div className="mt-4 pt-4 border-t border-white/[0.06]">
                          <Link
                            href="/corporate"
                            className="flex items-center justify-between px-4 py-3 rounded-xl bg-accent-cyan/[0.06] hover:bg-accent-cyan/[0.12] transition-colors duration-300 group/cta"
                          >
                            <div>
                              <p className="text-sm font-semibold text-text-primary">Corporate Training</p>
                              <p className="text-xs text-text-muted mt-0.5">Custom programs for your team</p>
                            </div>
                            <ArrowRight className="w-4 h-4 text-accent-cyan group-hover/cta:translate-x-1 transition-transform duration-300" />
                          </Link>
                        </div>
                      </div>
                    </motion.div>
                  )}
                </AnimatePresence>
              </div>
            )}

            {/* Plain links */}
            {plainLinks.map((link) => (
              <Link
                key={link.label}
                href={link.href}
                className={cn(
                  'relative px-4 py-2.5 text-[0.9rem] font-medium rounded-lg transition-all duration-300',
                  'text-text-secondary hover:text-white group',
                )}
              >
                <span>{link.label}</span>
                <span className="absolute bottom-1 left-4 right-4 h-px bg-accent-cyan scale-x-0 group-hover:scale-x-100 transition-transform duration-300 origin-left" />
              </Link>
            ))}
          </div>

          {/* ── Right section ── */}
          <div className="flex items-center gap-3">
            {/* CTA — desktop */}
            <Link
              href="/contact"
              className="hidden lg:inline-flex relative group items-center gap-2 px-6 py-2.5 rounded-full text-sm font-semibold text-bg-primary bg-accent-cyan overflow-hidden transition-all duration-300 hover:shadow-[0_0_24px_rgba(0,229,255,0.35)]"
            >
              {/* shimmer sweep */}
              <span className="absolute inset-0 -translate-x-full group-hover:translate-x-full transition-transform duration-700 bg-gradient-to-r from-transparent via-white/25 to-transparent pointer-events-none" />
              <span className="relative z-10">Enroll Now</span>
            </Link>

            {/* Hamburger — mobile */}
            <button
              onClick={() => setMobileOpen(!mobileOpen)}
              className="lg:hidden relative w-10 h-10 flex items-center justify-center rounded-lg text-text-secondary hover:text-white hover:bg-white/[0.06] transition-all duration-300"
              aria-label="Toggle menu"
            >
              <AnimatePresence mode="wait" initial={false}>
                {mobileOpen ? (
                  <motion.span
                    key="close"
                    initial={{ rotate: -90, opacity: 0 }}
                    animate={{ rotate: 0, opacity: 1 }}
                    exit={{ rotate: 90, opacity: 0 }}
                    transition={{ duration: 0.2 }}
                  >
                    <X className="w-5 h-5" />
                  </motion.span>
                ) : (
                  <motion.span
                    key="menu"
                    initial={{ rotate: 90, opacity: 0 }}
                    animate={{ rotate: 0, opacity: 1 }}
                    exit={{ rotate: -90, opacity: 0 }}
                    transition={{ duration: 0.2 }}
                  >
                    <Menu className="w-5 h-5" />
                  </motion.span>
                )}
              </AnimatePresence>
            </button>
          </div>
        </nav>
      </motion.header>

      {/* ── Mobile Overlay Menu ── */}
      <AnimatePresence>
        {mobileOpen && (
          <motion.div
            key="mobile-overlay"
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            exit={{ opacity: 0 }}
            transition={{ duration: 0.3 }}
            className="fixed inset-0 z-40 lg:hidden"
          >
            {/* backdrop */}
            <div className="absolute inset-0 bg-bg-primary/95 backdrop-blur-2xl" />

            {/* content */}
            <div className="relative z-10 h-full flex flex-col pt-24 pb-8 px-6 overflow-y-auto">
              {/* cyber grid decoration */}
              <div className="absolute inset-0 cyber-grid opacity-30 pointer-events-none" />

              <nav className="relative flex flex-col gap-1">
                {/* Training accordion */}
                {trainingLink && (
                  <div>
                    <motion.button
                      initial={{ opacity: 0, x: -20 }}
                      animate={{ opacity: 1, x: 0 }}
                      transition={{ delay: 0.05, duration: 0.4, ease: [0.16, 1, 0.3, 1] }}
                      onClick={() => setMobileTrainingOpen(!mobileTrainingOpen)}
                      className="w-full flex items-center justify-between py-3.5 text-xl font-semibold text-text-primary hover:text-accent-cyan transition-colors"
                    >
                      <span>{trainingLink.label}</span>
                      <ChevronDown
                        className={cn(
                          'w-5 h-5 text-text-muted transition-transform duration-300',
                          mobileTrainingOpen && 'rotate-180 text-accent-cyan',
                        )}
                      />
                    </motion.button>

                    <AnimatePresence>
                      {mobileTrainingOpen && (
                        <motion.div
                          initial={{ height: 0, opacity: 0 }}
                          animate={{ height: 'auto', opacity: 1 }}
                          exit={{ height: 0, opacity: 0 }}
                          transition={{ duration: 0.3, ease: [0.16, 1, 0.3, 1] }}
                          className="overflow-hidden"
                        >
                          <div className="pl-4 pb-2 flex flex-col gap-1 border-l border-accent-cyan/20">
                            {trainingLink.children!.map((child, i) => (
                              <motion.div
                                key={child.label}
                                initial={{ opacity: 0, x: -10 }}
                                animate={{ opacity: 1, x: 0 }}
                                transition={{ delay: i * 0.05 }}
                              >
                                <Link
                                  href={child.href}
                                  onClick={closeMobile}
                                  className="flex items-center gap-3 py-2.5 px-3 rounded-lg text-text-secondary hover:text-white hover:bg-white/[0.04] transition-all duration-200"
                                >
                                  <span
                                    className="w-2 h-2 rounded-full shrink-0"
                                    style={{ background: vendorColors[child.label] ?? '#00E5FF' }}
                                  />
                                  <div>
                                    <p className="text-sm font-medium">{child.label}</p>
                                    <p className="text-xs text-text-muted">{child.description}</p>
                                  </div>
                                </Link>
                              </motion.div>
                            ))}
                          </div>
                        </motion.div>
                      )}
                    </AnimatePresence>
                  </div>
                )}

                {/* Plain links */}
                {plainLinks.map((link, i) => (
                  <motion.div
                    key={link.label}
                    initial={{ opacity: 0, x: -20 }}
                    animate={{ opacity: 1, x: 0 }}
                    transition={{
                      delay: 0.08 + i * 0.06,
                      duration: 0.4,
                      ease: [0.16, 1, 0.3, 1],
                    }}
                  >
                    <Link
                      href={link.href}
                      onClick={closeMobile}
                      className="block py-3.5 text-xl font-semibold text-text-primary hover:text-accent-cyan transition-colors duration-200"
                    >
                      {link.label}
                    </Link>
                  </motion.div>
                ))}
              </nav>

              {/* Mobile CTA */}
              <motion.div
                initial={{ opacity: 0, y: 20 }}
                animate={{ opacity: 1, y: 0 }}
                transition={{ delay: 0.5, duration: 0.5 }}
                className="mt-auto pt-8"
              >
                <Link
                  href="/contact"
                  onClick={closeMobile}
                  className="flex items-center justify-center gap-2 w-full py-4 rounded-2xl text-base font-semibold text-bg-primary bg-accent-cyan hover:shadow-[0_0_30px_rgba(0,229,255,0.3)] transition-all duration-300"
                >
                  Enroll Now
                  <ArrowRight className="w-4 h-4" />
                </Link>
                <p className="text-center text-xs text-text-muted mt-4">
                  +91 99721 77745 · info@gitinfo.com
                </p>
              </motion.div>
            </div>
          </motion.div>
        )}
      </AnimatePresence>
    </>
  );
}
